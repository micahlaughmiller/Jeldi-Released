"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc2) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc2 = __getOwnPropDesc(from, key)) || desc2.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/lambda.ts
var lambda_exports = {};
__export(lambda_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(lambda_exports);
var import_express = __toESM(require("express"), 1);
var import_serverless_http = __toESM(require("serverless-http"), 1);

// server/routes.ts
var import_http = require("http");
var import_ws2 = require("ws");

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  chatHistory: () => chatHistory,
  chatHistoryRelations: () => chatHistoryRelations,
  emailConfigurationRelations: () => emailConfigurationRelations,
  emailConfigurations: () => emailConfigurations,
  erpConnectionRelations: () => erpConnectionRelations,
  erpConnections: () => erpConnections,
  insertChatHistorySchema: () => insertChatHistorySchema,
  insertEmailConfigurationSchema: () => insertEmailConfigurationSchema,
  insertErpConnectionSchema: () => insertErpConnectionSchema,
  insertKpiConfigurationSchema: () => insertKpiConfigurationSchema,
  insertKpiDataSchema: () => insertKpiDataSchema,
  insertOAuthSessionSchema: () => insertOAuthSessionSchema,
  insertOAuthUserSchema: () => insertOAuthUserSchema,
  insertUserSchema: () => insertUserSchema,
  kpiConfigurationRelations: () => kpiConfigurationRelations,
  kpiConfigurations: () => kpiConfigurations,
  kpiData: () => kpiData,
  kpiDataRelations: () => kpiDataRelations,
  oauthSessions: () => oauthSessions,
  userRelations: () => userRelations,
  users: () => users
});
var import_drizzle_orm = require("drizzle-orm");
var import_pg_core = require("drizzle-orm/pg-core");
var import_drizzle_orm2 = require("drizzle-orm");
var import_drizzle_zod = require("drizzle-zod");
var import_zod = require("zod");
var users = (0, import_pg_core.pgTable)("users", {
  id: (0, import_pg_core.uuid)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  username: (0, import_pg_core.text)("username").notNull().unique(),
  email: (0, import_pg_core.text)("email").notNull().unique(),
  password: (0, import_pg_core.text)("password"),
  // Optional for OAuth users
  role: (0, import_pg_core.text)("role").notNull().default("user"),
  // OAuth authentication fields
  authProvider: (0, import_pg_core.text)("auth_provider").default("local"),
  // local, google, microsoft
  oauthId: (0, import_pg_core.text)("oauth_id"),
  // OAuth provider user ID
  profileImage: (0, import_pg_core.text)("profile_image"),
  // OAuth profile image URL
  firstName: (0, import_pg_core.text)("first_name"),
  // OAuth first name
  lastName: (0, import_pg_core.text)("last_name"),
  // OAuth last name
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow().notNull()
});
var erpConnections = (0, import_pg_core.pgTable)("erp_connections", {
  id: (0, import_pg_core.uuid)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  userId: (0, import_pg_core.uuid)("user_id").references(() => users.id).notNull(),
  erpSystem: (0, import_pg_core.text)("erp_system").notNull(),
  // SAP, NetSuite, Dynamics365, etc.
  isConnected: (0, import_pg_core.boolean)("is_connected").default(false).notNull(),
  accessToken: (0, import_pg_core.text)("access_token"),
  refreshToken: (0, import_pg_core.text)("refresh_token"),
  tokenExpiry: (0, import_pg_core.timestamp)("token_expiry"),
  config: (0, import_pg_core.jsonb)("config"),
  // OAuth config and endpoints
  lastSync: (0, import_pg_core.timestamp)("last_sync"),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow().notNull()
});
var kpiConfigurations = (0, import_pg_core.pgTable)("kpi_configurations", {
  id: (0, import_pg_core.uuid)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  userId: (0, import_pg_core.uuid)("user_id").references(() => users.id).notNull(),
  name: (0, import_pg_core.text)("name").notNull(),
  type: (0, import_pg_core.text)("type").notNull(),
  // revenue, orders, inventory, performance, efficiency
  erpSource: (0, import_pg_core.text)("erp_source").notNull(),
  query: (0, import_pg_core.text)("query").notNull(),
  // SQL or API query for data
  position: (0, import_pg_core.integer)("position").notNull(),
  // Dashboard position 1-5
  isActive: (0, import_pg_core.boolean)("is_active").default(true).notNull(),
  refreshInterval: (0, import_pg_core.integer)("refresh_interval").default(30).notNull(),
  // seconds
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow().notNull()
});
var kpiData = (0, import_pg_core.pgTable)("kpi_data", {
  id: (0, import_pg_core.uuid)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  kpiId: (0, import_pg_core.uuid)("kpi_id").references(() => kpiConfigurations.id).notNull(),
  value: (0, import_pg_core.text)("value").notNull(),
  change: (0, import_pg_core.decimal)("change", { precision: 5, scale: 2 }),
  timestamp: (0, import_pg_core.timestamp)("timestamp").defaultNow().notNull()
});
var emailConfigurations = (0, import_pg_core.pgTable)("email_configurations", {
  id: (0, import_pg_core.uuid)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  userId: (0, import_pg_core.uuid)("user_id").references(() => users.id).notNull(),
  provider: (0, import_pg_core.text)("provider").notNull(),
  // gmail, outlook
  email: (0, import_pg_core.text)("email").notNull(),
  accessToken: (0, import_pg_core.text)("access_token"),
  refreshToken: (0, import_pg_core.text)("refresh_token"),
  tokenExpiry: (0, import_pg_core.timestamp)("token_expiry"),
  isActive: (0, import_pg_core.boolean)("is_active").default(true).notNull(),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow().notNull()
});
var oauthSessions = (0, import_pg_core.pgTable)("oauth_sessions", {
  id: (0, import_pg_core.uuid)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  state: (0, import_pg_core.text)("state").notNull().unique(),
  // CSRF protection state
  provider: (0, import_pg_core.text)("provider").notNull(),
  // google, microsoft
  isCompleted: (0, import_pg_core.boolean)("is_completed").default(false).notNull(),
  authResult: (0, import_pg_core.jsonb)("auth_result"),
  // Temporary storage for JWT and user data
  expiresAt: (0, import_pg_core.timestamp)("expires_at").notNull(),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow().notNull()
});
var chatHistory = (0, import_pg_core.pgTable)("chat_history", {
  id: (0, import_pg_core.uuid)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  userId: (0, import_pg_core.uuid)("user_id").references(() => users.id).notNull(),
  query: (0, import_pg_core.text)("query").notNull(),
  response: (0, import_pg_core.text)("response").notNull(),
  erpData: (0, import_pg_core.jsonb)("erp_data"),
  // Context data used for the query
  timestamp: (0, import_pg_core.timestamp)("timestamp").defaultNow().notNull()
});
var userRelations = (0, import_drizzle_orm2.relations)(users, ({ many }) => ({
  erpConnections: many(erpConnections),
  kpiConfigurations: many(kpiConfigurations),
  emailConfigurations: many(emailConfigurations),
  chatHistory: many(chatHistory)
}));
var erpConnectionRelations = (0, import_drizzle_orm2.relations)(erpConnections, ({ one }) => ({
  user: one(users, {
    fields: [erpConnections.userId],
    references: [users.id]
  })
}));
var kpiConfigurationRelations = (0, import_drizzle_orm2.relations)(kpiConfigurations, ({ one, many }) => ({
  user: one(users, {
    fields: [kpiConfigurations.userId],
    references: [users.id]
  }),
  data: many(kpiData)
}));
var kpiDataRelations = (0, import_drizzle_orm2.relations)(kpiData, ({ one }) => ({
  kpi: one(kpiConfigurations, {
    fields: [kpiData.kpiId],
    references: [kpiConfigurations.id]
  })
}));
var emailConfigurationRelations = (0, import_drizzle_orm2.relations)(emailConfigurations, ({ one }) => ({
  user: one(users, {
    fields: [emailConfigurations.userId],
    references: [users.id]
  })
}));
var chatHistoryRelations = (0, import_drizzle_orm2.relations)(chatHistory, ({ one }) => ({
  user: one(users, {
    fields: [chatHistory.userId],
    references: [users.id]
  })
}));
var insertUserSchema = (0, import_drizzle_zod.createInsertSchema)(users).omit({
  id: true,
  createdAt: true
}).extend({
  password: import_zod.z.string().min(8).optional()
  // Make password optional for OAuth
});
var insertOAuthUserSchema = (0, import_drizzle_zod.createInsertSchema)(users).omit({
  id: true,
  createdAt: true,
  password: true
  // OAuth users don't need passwords
});
var insertErpConnectionSchema = (0, import_drizzle_zod.createInsertSchema)(erpConnections).omit({
  id: true,
  createdAt: true
});
var insertKpiConfigurationSchema = (0, import_drizzle_zod.createInsertSchema)(kpiConfigurations).omit({
  id: true,
  createdAt: true
});
var insertKpiDataSchema = (0, import_drizzle_zod.createInsertSchema)(kpiData).omit({
  id: true,
  timestamp: true
});
var insertEmailConfigurationSchema = (0, import_drizzle_zod.createInsertSchema)(emailConfigurations).omit({
  id: true,
  createdAt: true
});
var insertOAuthSessionSchema = (0, import_drizzle_zod.createInsertSchema)(oauthSessions).omit({
  id: true,
  createdAt: true
});
var insertChatHistorySchema = (0, import_drizzle_zod.createInsertSchema)(chatHistory).omit({
  id: true,
  timestamp: true
});

// server/db.ts
var import_serverless = require("@neondatabase/serverless");
var import_neon_serverless = require("drizzle-orm/neon-serverless");
var import_ws = __toESM(require("ws"), 1);
import_serverless.neonConfig.webSocketConstructor = import_ws.default;
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?"
  );
}
var pool = new import_serverless.Pool({ connectionString: process.env.DATABASE_URL });
var db = (0, import_neon_serverless.drizzle)({ client: pool, schema: schema_exports });

// server/storage.ts
var import_drizzle_orm3 = require("drizzle-orm");
var DatabaseStorage = class {
  async getUser(id) {
    const [user] = await db.select().from(users).where((0, import_drizzle_orm3.eq)(users.id, id));
    return user || void 0;
  }
  async getUserByUsername(username) {
    const [user] = await db.select().from(users).where((0, import_drizzle_orm3.eq)(users.username, username));
    return user || void 0;
  }
  async getUserByEmail(email) {
    const [user] = await db.select().from(users).where((0, import_drizzle_orm3.eq)(users.email, email));
    return user || void 0;
  }
  async createUser(insertUser) {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  async getUserByOAuthId(provider, oauthId) {
    const [user] = await db.select().from(users).where((0, import_drizzle_orm3.and)((0, import_drizzle_orm3.eq)(users.authProvider, provider), (0, import_drizzle_orm3.eq)(users.oauthId, oauthId)));
    return user || void 0;
  }
  async createOAuthUser(insertOAuthUser) {
    const [user] = await db.insert(users).values(insertOAuthUser).returning();
    return user;
  }
  async updateUser(id, updates) {
    const [user] = await db.update(users).set(updates).where((0, import_drizzle_orm3.eq)(users.id, id)).returning();
    return user || void 0;
  }
  async getErpConnections(userId) {
    return await db.select().from(erpConnections).where((0, import_drizzle_orm3.eq)(erpConnections.userId, userId));
  }
  async getErpConnection(userId, erpSystem) {
    const [connection] = await db.select().from(erpConnections).where((0, import_drizzle_orm3.and)((0, import_drizzle_orm3.eq)(erpConnections.userId, userId), (0, import_drizzle_orm3.eq)(erpConnections.erpSystem, erpSystem)));
    return connection || void 0;
  }
  async createErpConnection(connection) {
    const [newConnection] = await db.insert(erpConnections).values(connection).returning();
    return newConnection;
  }
  async updateErpConnection(id, updates) {
    const [updated] = await db.update(erpConnections).set(updates).where((0, import_drizzle_orm3.eq)(erpConnections.id, id)).returning();
    return updated || void 0;
  }
  async getKpiConfigurations(userId) {
    return await db.select().from(kpiConfigurations).where((0, import_drizzle_orm3.eq)(kpiConfigurations.userId, userId)).orderBy(kpiConfigurations.position);
  }
  async createKpiConfiguration(config) {
    const [newConfig] = await db.insert(kpiConfigurations).values(config).returning();
    return newConfig;
  }
  async updateKpiConfiguration(id, updates) {
    const [updated] = await db.update(kpiConfigurations).set(updates).where((0, import_drizzle_orm3.eq)(kpiConfigurations.id, id)).returning();
    return updated || void 0;
  }
  async deleteKpiConfiguration(id) {
    const result = await db.delete(kpiConfigurations).where((0, import_drizzle_orm3.eq)(kpiConfigurations.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getLatestKpiData(kpiId) {
    const [data] = await db.select().from(kpiData).where((0, import_drizzle_orm3.eq)(kpiData.kpiId, kpiId)).orderBy((0, import_drizzle_orm3.desc)(kpiData.timestamp)).limit(1);
    return data || void 0;
  }
  async createKpiData(data) {
    const [newData] = await db.insert(kpiData).values(data).returning();
    return newData;
  }
  async getKpiDataHistory(kpiId, limit = 50) {
    return await db.select().from(kpiData).where((0, import_drizzle_orm3.eq)(kpiData.kpiId, kpiId)).orderBy((0, import_drizzle_orm3.desc)(kpiData.timestamp)).limit(limit);
  }
  async getEmailConfigurations(userId) {
    return await db.select().from(emailConfigurations).where((0, import_drizzle_orm3.eq)(emailConfigurations.userId, userId));
  }
  async createEmailConfiguration(config) {
    const [newConfig] = await db.insert(emailConfigurations).values(config).returning();
    return newConfig;
  }
  async updateEmailConfiguration(id, updates) {
    const [updated] = await db.update(emailConfigurations).set(updates).where((0, import_drizzle_orm3.eq)(emailConfigurations.id, id)).returning();
    return updated || void 0;
  }
  async getChatHistory(userId, limit = 50) {
    return await db.select().from(chatHistory).where((0, import_drizzle_orm3.eq)(chatHistory.userId, userId)).orderBy((0, import_drizzle_orm3.desc)(chatHistory.timestamp)).limit(limit);
  }
  async createChatHistory(chat) {
    const [newChat] = await db.insert(chatHistory).values(chat).returning();
    return newChat;
  }
  async createOAuthSession(session) {
    const [newSession] = await db.insert(oauthSessions).values(session).returning();
    return newSession;
  }
  async getOAuthSession(id) {
    const [session] = await db.select().from(oauthSessions).where((0, import_drizzle_orm3.eq)(oauthSessions.id, id));
    return session || void 0;
  }
  async getOAuthSessionByState(state) {
    const [session] = await db.select().from(oauthSessions).where((0, import_drizzle_orm3.eq)(oauthSessions.state, state));
    return session || void 0;
  }
  async updateOAuthSession(id, updates) {
    const [updated] = await db.update(oauthSessions).set(updates).where((0, import_drizzle_orm3.eq)(oauthSessions.id, id)).returning();
    return updated || void 0;
  }
  async deleteOAuthSession(id) {
    const result = await db.delete(oauthSessions).where((0, import_drizzle_orm3.eq)(oauthSessions.id, id));
    return (result.rowCount || 0) > 0;
  }
  async cleanupExpiredOAuthSessions() {
    await db.delete(oauthSessions).where(import_drizzle_orm3.sql`${oauthSessions.expiresAt} < NOW()`);
  }
};
var storage = new DatabaseStorage();

// server/services/erpService.ts
var ERP_SYSTEMS = {
  sap: {
    name: "sap",
    displayName: "SAP S/4HANA",
    description: "AI-driven analytics, in-memory computing",
    oauthConfig: {
      authUrl: "https://api.sap.com/oauth/authorize",
      tokenUrl: "https://api.sap.com/oauth/token",
      clientId: process.env.SAP_CLIENT_ID || "",
      scopes: ["read", "write", "analytics"]
    },
    apiBaseUrl: "https://api.sap.com/v1"
  },
  netsuite: {
    name: "netsuite",
    displayName: "Oracle NetSuite",
    description: "Cloud-native, financial management",
    oauthConfig: {
      authUrl: "https://system.netsuite.com/app/login/oauth2/authorize.nl",
      tokenUrl: "https://system.netsuite.com/app/login/oauth2/token.nl",
      clientId: process.env.NETSUITE_CLIENT_ID || "",
      scopes: ["restlets", "rest_webservices"]
    },
    apiBaseUrl: "https://system.netsuite.com/app/site/hosting/restlet.nl"
  },
  dynamics365: {
    name: "dynamics365",
    displayName: "Microsoft Dynamics 365",
    description: "Office 365 integration, Copilot AI",
    oauthConfig: {
      authUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
      tokenUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/token",
      clientId: process.env.DYNAMICS_CLIENT_ID || "",
      scopes: ["https://service.powerapps.com/user_impersonation"]
    },
    apiBaseUrl: "https://api.businesscentral.dynamics.com/v2.0"
  },
  oracle_fusion: {
    name: "oracle_fusion",
    displayName: "Oracle Fusion Cloud",
    description: "Large enterprise focus, robust functionality",
    oauthConfig: {
      authUrl: "https://idcs-oracle.identity.oraclecloud.com/oauth2/v1/authorize",
      tokenUrl: "https://idcs-oracle.identity.oraclecloud.com/oauth2/v1/token",
      clientId: process.env.ORACLE_FUSION_CLIENT_ID || "",
      scopes: ["urn:opc:idm:__myscopes__"]
    },
    apiBaseUrl: "https://api.oraclecloud.com/20160918"
  },
  workday: {
    name: "workday",
    displayName: "Workday ERP",
    description: "HR-centric, cloud-first design",
    oauthConfig: {
      authUrl: "https://impl-cc.workday.com/ccx/oauth2/authorize",
      tokenUrl: "https://impl-cc.workday.com/ccx/oauth2/token",
      clientId: process.env.WORKDAY_CLIENT_ID || "",
      scopes: ["openid", "profile"]
    },
    apiBaseUrl: "https://wd2-impl-services1.workday.com"
  },
  ifs: {
    name: "ifs",
    displayName: "IFS Cloud",
    description: "Asset management, field service",
    oauthConfig: {
      authUrl: "https://oauth.ifs.com/authorize",
      tokenUrl: "https://oauth.ifs.com/token",
      clientId: process.env.IFS_CLIENT_ID || "",
      scopes: ["read", "write"]
    },
    apiBaseUrl: "https://api.ifs.com/v1"
  },
  epicor: {
    name: "epicor",
    displayName: "Epicor Kinetic",
    description: "Manufacturing focus, modern interface",
    oauthConfig: {
      authUrl: "https://api.epicor.com/oauth/authorize",
      tokenUrl: "https://api.epicor.com/oauth/token",
      clientId: process.env.EPICOR_CLIENT_ID || "",
      scopes: ["erp.read", "erp.write"]
    },
    apiBaseUrl: "https://api.epicor.com/v1"
  },
  infor: {
    name: "infor",
    displayName: "Infor LN/M3",
    description: "Industry-specific solutions",
    oauthConfig: {
      authUrl: "https://mingle-ionapi.inforcloudsuite.com/INFOR_GRID/as/authorization.oauth2",
      tokenUrl: "https://mingle-ionapi.inforcloudsuite.com/INFOR_GRID/as/token.oauth2",
      clientId: process.env.INFOR_CLIENT_ID || "",
      scopes: ["read", "write"]
    },
    apiBaseUrl: "https://mingle-ionapi.inforcloudsuite.com"
  },
  acumatica: {
    name: "acumatica",
    displayName: "Acumatica Cloud",
    description: "Modular pricing, construction/distribution",
    oauthConfig: {
      authUrl: "https://api.acumatica.com/oauth/authorize",
      tokenUrl: "https://api.acumatica.com/oauth/token",
      clientId: process.env.ACUMATICA_CLIENT_ID || "",
      scopes: ["api"]
    },
    apiBaseUrl: "https://api.acumatica.com/entity"
  },
  sage: {
    name: "sage",
    displayName: "Sage Intacct",
    description: "Financial management, accounting-first",
    oauthConfig: {
      authUrl: "https://api.intacct.com/ia/acct/oauth2/authorize",
      tokenUrl: "https://api.intacct.com/ia/acct/oauth2/token",
      clientId: process.env.SAGE_CLIENT_ID || "",
      scopes: ["read", "write"]
    },
    apiBaseUrl: "https://api.intacct.com"
  }
};
var ERPService = class {
  async getConnectedSystems(userId) {
    const connections = await storage.getErpConnections(userId);
    return Object.values(ERP_SYSTEMS).map((system) => ({
      ...system,
      isConnected: connections.some((conn) => conn.erpSystem === system.name && conn.isConnected),
      lastSync: connections.find((conn) => conn.erpSystem === system.name)?.lastSync || void 0
    }));
  }
  async initiateOAuthFlow(erpSystem, userId, redirectUri) {
    const system = ERP_SYSTEMS[erpSystem];
    if (!system) {
      throw new Error(`ERP system ${erpSystem} not supported`);
    }
    const existingConnection = await storage.getErpConnection(userId, erpSystem);
    if (!existingConnection) {
      await storage.createErpConnection({
        userId,
        erpSystem,
        isConnected: false,
        config: system.oauthConfig
      });
    }
    const params = new URLSearchParams({
      client_id: system.oauthConfig.clientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: system.oauthConfig.scopes.join(" "),
      state: `${userId}-${erpSystem}-${Date.now()}`
    });
    return `${system.oauthConfig.authUrl}?${params.toString()}`;
  }
  async handleOAuthCallback(code, state) {
    const [userId, erpSystem] = state.split("-");
    const system = ERP_SYSTEMS[erpSystem];
    if (!system) {
      throw new Error(`Invalid ERP system: ${erpSystem}`);
    }
    const tokenResponse = await fetch(system.oauthConfig.tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: system.oauthConfig.clientId,
        client_secret: process.env[`${erpSystem.toUpperCase()}_CLIENT_SECRET`] || "",
        code,
        redirect_uri: process.env.OAUTH_REDIRECT_URI || ""
      })
    });
    if (!tokenResponse.ok) {
      throw new Error(`Failed to exchange code for tokens: ${tokenResponse.statusText}`);
    }
    const tokens = await tokenResponse.json();
    const connection = await storage.getErpConnection(userId, erpSystem);
    if (!connection) {
      throw new Error("Connection not found");
    }
    const updatedConnection = await storage.updateErpConnection(connection.id, {
      isConnected: true,
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      tokenExpiry: new Date(Date.now() + tokens.expires_in * 1e3),
      lastSync: /* @__PURE__ */ new Date()
    });
    if (!updatedConnection) {
      throw new Error("Failed to update connection");
    }
    return updatedConnection;
  }
  async fetchERPData(userId, erpSystem, endpoint) {
    const connection = await storage.getErpConnection(userId, erpSystem);
    if (!connection || !connection.isConnected || !connection.accessToken) {
      throw new Error(`${erpSystem} not connected`);
    }
    const system = ERP_SYSTEMS[erpSystem];
    const response = await fetch(`${system.apiBaseUrl}${endpoint}`, {
      headers: {
        "Authorization": `Bearer ${connection.accessToken}`,
        "Content-Type": "application/json"
      }
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch data from ${erpSystem}: ${response.statusText}`);
    }
    await storage.updateErpConnection(connection.id, {
      lastSync: /* @__PURE__ */ new Date()
    });
    return await response.json();
  }
  async aggregateERPData(userId) {
    const connections = await storage.getErpConnections(userId);
    const connectedSystems = connections.filter((conn) => conn.isConnected);
    const aggregatedData = {};
    for (const connection of connectedSystems) {
      try {
        const data = await this.fetchERPData(userId, connection.erpSystem, "/summary");
        aggregatedData[connection.erpSystem] = data;
      } catch (error) {
        console.error(`Failed to fetch data from ${connection.erpSystem}:`, error);
        aggregatedData[connection.erpSystem] = { error: error.message };
      }
    }
    return aggregatedData;
  }
  async disconnectSystem(userId, erpSystem) {
    const connection = await storage.getErpConnection(userId, erpSystem);
    if (!connection) {
      throw new Error(`${erpSystem} connection not found`);
    }
    await storage.updateErpConnection(connection.id, {
      isConnected: false,
      accessToken: null,
      refreshToken: null,
      tokenExpiry: null,
      lastSync: null
    });
  }
};
var erpService = new ERPService();

// server/services/emailService.ts
var EMAIL_PROVIDERS = {
  gmail: {
    name: "gmail",
    displayName: "Gmail",
    oauthConfig: {
      authUrl: "https://accounts.google.com/o/oauth2/v2/auth",
      tokenUrl: "https://oauth2.googleapis.com/token",
      clientId: process.env.GMAIL_CLIENT_ID || "",
      scopes: ["https://www.googleapis.com/auth/gmail.send", "https://www.googleapis.com/auth/gmail.readonly"]
    },
    sendEndpoint: "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
  },
  outlook: {
    name: "outlook",
    displayName: "Outlook.com",
    oauthConfig: {
      authUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
      tokenUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/token",
      clientId: process.env.OUTLOOK_CLIENT_ID || "",
      scopes: ["https://graph.microsoft.com/Mail.Send", "https://graph.microsoft.com/Mail.Read"]
    },
    sendEndpoint: "https://graph.microsoft.com/v1.0/me/sendMail"
  }
};
var EMAIL_TEMPLATES = {
  weekly_report: {
    name: "Weekly Report",
    subject: "ERP Dashboard Report - Week {{week}}",
    body: `Dear {{recipient}},

Please find attached your weekly ERP dashboard report containing:

{{#kpis}}
- {{name}}: {{value}} ({{change}})
{{/kpis}}

Key Insights:
{{#insights}}
- {{.}}
{{/insights}}

Best regards,
ERP Connect Pro`,
    variables: ["week", "recipient", "kpis", "insights"]
  },
  kpi_alert: {
    name: "KPI Alert",
    subject: "Alert: {{kpi_name}} Threshold Exceeded",
    body: `Alert: {{kpi_name}} has exceeded the configured threshold.

Current Value: {{current_value}}
Threshold: {{threshold}}
Change: {{change}}

Please review and take appropriate action.

ERP Connect Pro`,
    variables: ["kpi_name", "current_value", "threshold", "change"]
  },
  system_status: {
    name: "System Status Update",
    subject: "ERP System Status Update",
    body: `System Status Update:

{{#systems}}
- {{name}}: {{status}} (Last sync: {{last_sync}})
{{/systems}}

{{#if issues}}
Issues requiring attention:
{{#issues}}
- {{.}}
{{/issues}}
{{/if}}

ERP Connect Pro`,
    variables: ["systems", "issues"]
  }
};
var EmailService = class {
  async getEmailConfigurations(userId) {
    return await storage.getEmailConfigurations(userId);
  }
  async initiateEmailOAuth(provider, userId, redirectUri) {
    const emailProvider = EMAIL_PROVIDERS[provider];
    if (!emailProvider) {
      throw new Error(`Email provider ${provider} not supported`);
    }
    const existingConfig = await storage.getEmailConfigurations(userId);
    const existing = existingConfig.find((config) => config.provider === provider);
    if (!existing) {
      await storage.createEmailConfiguration({
        userId,
        provider,
        email: "",
        // Will be updated after OAuth
        isActive: false
      });
    }
    const params = new URLSearchParams({
      client_id: emailProvider.oauthConfig.clientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: emailProvider.oauthConfig.scopes.join(" "),
      state: `${userId}-${provider}-${Date.now()}`
    });
    return `${emailProvider.oauthConfig.authUrl}?${params.toString()}`;
  }
  async handleEmailOAuthCallback(code, state) {
    const [userId, provider] = state.split("-");
    const emailProvider = EMAIL_PROVIDERS[provider];
    if (!emailProvider) {
      throw new Error(`Invalid email provider: ${provider}`);
    }
    const tokenResponse = await fetch(emailProvider.oauthConfig.tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: emailProvider.oauthConfig.clientId,
        client_secret: process.env[`${provider.toUpperCase()}_CLIENT_SECRET`] || "",
        code,
        redirect_uri: process.env.EMAIL_OAUTH_REDIRECT_URI || ""
      })
    });
    if (!tokenResponse.ok) {
      throw new Error(`Failed to exchange code for tokens: ${tokenResponse.statusText}`);
    }
    const tokens = await tokenResponse.json();
    let userEmail = "";
    if (provider === "gmail") {
      const profileResponse = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/profile", {
        headers: { "Authorization": `Bearer ${tokens.access_token}` }
      });
      const profile = await profileResponse.json();
      userEmail = profile.emailAddress;
    } else if (provider === "outlook") {
      const profileResponse = await fetch("https://graph.microsoft.com/v1.0/me", {
        headers: { "Authorization": `Bearer ${tokens.access_token}` }
      });
      const profile = await profileResponse.json();
      userEmail = profile.mail || profile.userPrincipalName;
    }
    const configurations = await storage.getEmailConfigurations(userId);
    const config = configurations.find((c) => c.provider === provider);
    if (!config) {
      throw new Error("Email configuration not found");
    }
    const updatedConfig = await storage.updateEmailConfiguration(config.id, {
      email: userEmail,
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      tokenExpiry: new Date(Date.now() + tokens.expires_in * 1e3),
      isActive: true
    });
    if (!updatedConfig) {
      throw new Error("Failed to update email configuration");
    }
    return updatedConfig;
  }
  async sendEmail(userId, provider, message) {
    const configurations = await storage.getEmailConfigurations(userId);
    const config = configurations.find((c) => c.provider === provider && c.isActive);
    if (!config || !config.accessToken) {
      throw new Error(`${provider} not configured or not active`);
    }
    const emailProvider = EMAIL_PROVIDERS[provider];
    try {
      if (provider === "gmail") {
        return await this.sendGmailMessage(config.accessToken, message);
      } else if (provider === "outlook") {
        return await this.sendOutlookMessage(config.accessToken, message);
      }
      throw new Error(`Unsupported provider: ${provider}`);
    } catch (error) {
      console.error(`Failed to send email via ${provider}:`, error);
      throw error;
    }
  }
  async sendGmailMessage(accessToken, message) {
    const email = this.buildRFC2822Message(message);
    const base64Email = Buffer.from(email).toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
    const response = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ raw: base64Email })
    });
    return response.ok;
  }
  async sendOutlookMessage(accessToken, message) {
    const outlookMessage = {
      message: {
        subject: message.subject,
        body: {
          contentType: message.isHtml ? "HTML" : "Text",
          content: message.body
        },
        toRecipients: message.to.map((email) => ({ emailAddress: { address: email } })),
        ccRecipients: message.cc?.map((email) => ({ emailAddress: { address: email } })) || [],
        bccRecipients: message.bcc?.map((email) => ({ emailAddress: { address: email } })) || []
      }
    };
    const response = await fetch("https://graph.microsoft.com/v1.0/me/sendMail", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(outlookMessage)
    });
    return response.ok;
  }
  buildRFC2822Message(message) {
    const lines = [
      `To: ${message.to.join(", ")}`,
      `Subject: ${message.subject}`,
      `Content-Type: ${message.isHtml ? "text/html" : "text/plain"}; charset=utf-8`,
      "",
      message.body
    ];
    if (message.cc && message.cc.length > 0) {
      lines.splice(1, 0, `Cc: ${message.cc.join(", ")}`);
    }
    if (message.bcc && message.bcc.length > 0) {
      lines.splice(1, 0, `Bcc: ${message.bcc.join(", ")}`);
    }
    return lines.join("\r\n");
  }
  getEmailTemplates() {
    return EMAIL_TEMPLATES;
  }
  renderTemplate(template, variables) {
    let subject = template.subject;
    let body = template.body;
    Object.keys(variables).forEach((key) => {
      const regex = new RegExp(`{{${key}}}`, "g");
      subject = subject.replace(regex, String(variables[key]));
      body = body.replace(regex, String(variables[key]));
    });
    return { subject, body };
  }
};
var emailService = new EmailService();

// server/services/openai.ts
var import_openai = __toESM(require("openai"), 1);
var openai = new import_openai.default({
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});
async function analyzeERPData(request) {
  try {
    const systemPrompt = `You are an expert ERP data analyst with deep knowledge of enterprise systems like SAP S/4HANA, Oracle NetSuite, Microsoft Dynamics 365, and other major ERP platforms. 

Your role is to:
1. Analyze ERP data and provide actionable business insights
2. Answer questions about financial performance, operations, inventory, and system efficiency
3. Identify trends and anomalies in the data
4. Provide strategic recommendations based on the data

You have access to real-time ERP data including:
- Financial metrics (revenue, expenses, profit margins)
- Operational data (orders, inventory, performance)
- System metrics (uptime, sync status, data quality)
- Historical trends and comparisons

Always respond with structured JSON containing your analysis, insights, and recommendations. Be specific and actionable.`;
    const userPrompt = `User Query: ${request.query}

Available ERP Data:
${JSON.stringify(request.erpData, null, 2)}

Please analyze this data and provide:
1. A direct answer to the user's question
2. Key insights from the data
3. Actionable recommendations
4. List of data sources used in your analysis

Respond in JSON format with the structure: { "response": "string", "insights": ["string"], "recommendations": ["string"], "dataUsed": ["string"] }`;
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 1e3
    });
    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      response: result.response || "Unable to analyze the data at this time.",
      insights: result.insights || [],
      recommendations: result.recommendations || [],
      dataUsed: result.dataUsed || []
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to analyze ERP data: " + error.message);
  }
}
async function generateKPIInsights(kpiData2) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a KPI analyst. Analyze the provided KPI data and generate insights about performance trends, alerts for concerning metrics, and overall business health. Respond in JSON format."
        },
        {
          role: "user",
          content: `Analyze these KPI metrics and provide insights:
          
          ${JSON.stringify(kpiData2, null, 2)}
          
          Respond with JSON: { "summary": "string", "alerts": ["string"], "trends": ["string"] }`
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 500
    });
    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      summary: result.summary || "KPI analysis unavailable",
      alerts: result.alerts || [],
      trends: result.trends || []
    };
  } catch (error) {
    console.error("KPI analysis error:", error);
    return {
      summary: "Unable to analyze KPI data",
      alerts: [],
      trends: []
    };
  }
}

// server/routes.ts
var import_bcrypt = __toESM(require("bcrypt"), 1);
var import_jsonwebtoken2 = __toESM(require("jsonwebtoken"), 1);
var import_passport2 = __toESM(require("passport"), 1);

// server/services/oauthService.ts
var import_passport = __toESM(require("passport"), 1);
var import_passport_google_oauth20 = require("passport-google-oauth20");
var import_passport_microsoft = require("passport-microsoft");
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_crypto = __toESM(require("crypto"), 1);

// server/env-validation.ts
var REQUIRED_ENV_VARS = [
  {
    name: "JWT_SECRET",
    description: "Secret key for signing JWT tokens",
    example: "openssl rand -base64 64"
  }
];
var OPTIONAL_ENV_VARS = [
  {
    name: "GOOGLE_CLIENT_ID",
    description: "Google OAuth client ID",
    impact: "Google OAuth login will be unavailable"
  },
  {
    name: "GOOGLE_CLIENT_SECRET",
    description: "Google OAuth client secret",
    impact: "Google OAuth login will be unavailable"
  },
  {
    name: "MICROSOFT_CLIENT_ID",
    description: "Microsoft OAuth client ID",
    impact: "Microsoft OAuth login will be unavailable"
  },
  {
    name: "MICROSOFT_CLIENT_SECRET",
    description: "Microsoft OAuth client secret",
    impact: "Microsoft OAuth login will be unavailable"
  }
];
function validateEnvironment() {
  const errors = [];
  const warnings = [];
  for (const envVar of REQUIRED_ENV_VARS) {
    const value = process.env[envVar.name];
    if (!value || value.trim() === "") {
      errors.push(`Missing required environment variable: ${envVar.name}`);
      errors.push(`  Description: ${envVar.description}`);
      if (envVar.example) {
        errors.push(`  Example: ${envVar.example}`);
      }
    }
  }
  for (const envVar of OPTIONAL_ENV_VARS) {
    const value = process.env[envVar.name];
    if (!value || value.trim() === "") {
      warnings.push(`Optional environment variable not set: ${envVar.name}`);
      warnings.push(`  Impact: ${envVar.impact}`);
    }
  }
  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}
function enforceEnvironmentValidation() {
  const result = validateEnvironment();
  if (!result.isValid) {
    console.error("\n\u274C CRITICAL: Application startup failed due to missing required environment variables:\n");
    result.errors.forEach((error) => console.error(`  ${error}`));
    console.error("\nApplication cannot start without these variables. Please set them and restart.\n");
    process.exit(1);
  }
  if (result.warnings.length > 0) {
    console.warn("\n\u26A0\uFE0F  WARNING: Some optional environment variables are not set:\n");
    result.warnings.forEach((warning) => console.warn(`  ${warning}`));
    console.warn("\n");
  }
}
function getJwtSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET environment variable is not set. This should have been caught during startup validation.");
  }
  return secret;
}

// server/services/oauthService.ts
var getJwtSecretAtRuntime = () => getJwtSecret();
var OAUTH_PROVIDERS = {
  google: {
    name: "google",
    displayName: "Google",
    clientId: process.env.GOOGLE_CLIENT_ID || "",
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
    callbackURL: process.env.GOOGLE_CALLBACK_URL || "/api/auth/google/callback",
    scope: ["profile", "email"]
  },
  microsoft: {
    name: "microsoft",
    displayName: "Microsoft",
    clientId: process.env.MICROSOFT_CLIENT_ID || "",
    clientSecret: process.env.MICROSOFT_CLIENT_SECRET || "",
    callbackURL: process.env.MICROSOFT_CALLBACK_URL || "/api/auth/microsoft/callback",
    scope: ["openid", "profile", "email", "offline_access", "User.Read"]
  }
};
var OAuthService = class _OAuthService {
  static generateSecureState() {
    return import_crypto.default.randomBytes(32).toString("hex");
  }
  static async createOAuthSession(provider, state) {
    const expiresAt = new Date(Date.now() + 10 * 60 * 1e3);
    await storage.createOAuthSession({
      state,
      provider,
      isCompleted: false,
      expiresAt,
      authResult: null
    });
  }
  static async validateAndCompleteOAuthSession(state, authResult) {
    const session = await storage.getOAuthSessionByState(state);
    if (!session || session.isCompleted || /* @__PURE__ */ new Date() > session.expiresAt) {
      return false;
    }
    await storage.updateOAuthSession(session.id, {
      isCompleted: true,
      authResult
    });
    return true;
  }
  static async getCompletedOAuthSession(sessionId) {
    const session = await storage.getOAuthSession(sessionId);
    if (!session || !session.isCompleted) {
      return null;
    }
    await storage.deleteOAuthSession(session.id);
    return session.authResult;
  }
  static setupStrategies() {
    if (OAUTH_PROVIDERS.google.clientId && OAUTH_PROVIDERS.google.clientSecret) {
      import_passport.default.use(new import_passport_google_oauth20.Strategy(
        {
          clientID: OAUTH_PROVIDERS.google.clientId,
          clientSecret: OAUTH_PROVIDERS.google.clientSecret,
          callbackURL: OAUTH_PROVIDERS.google.callbackURL,
          passReqToCallback: true
        },
        async (req, accessToken, refreshToken, profile, done) => {
          try {
            const state = req.query?.state;
            if (!state) {
              return done(new Error("Missing CSRF state parameter"), null);
            }
            const result = await _OAuthService.handleOAuthCallback("google", profile, accessToken, refreshToken, state);
            return done(null, result);
          } catch (error) {
            return done(error, null);
          }
        }
      ));
    }
    if (OAUTH_PROVIDERS.microsoft.clientId && OAUTH_PROVIDERS.microsoft.clientSecret) {
      import_passport.default.use(new import_passport_microsoft.Strategy(
        {
          clientID: OAUTH_PROVIDERS.microsoft.clientId,
          clientSecret: OAUTH_PROVIDERS.microsoft.clientSecret,
          callbackURL: OAUTH_PROVIDERS.microsoft.callbackURL,
          scope: OAUTH_PROVIDERS.microsoft.scope,
          passReqToCallback: true
        },
        async (req, accessToken, refreshToken, profile, done) => {
          try {
            const state = req.query?.state;
            if (!state) {
              return done(new Error("Missing CSRF state parameter"), null);
            }
            const result = await _OAuthService.handleOAuthCallback("microsoft", profile, accessToken, refreshToken, state);
            return done(null, result);
          } catch (error) {
            return done(error, null);
          }
        }
      ));
    }
    import_passport.default.serializeUser((user, done) => {
      done(null, user);
    });
    import_passport.default.deserializeUser((user, done) => {
      done(null, user);
    });
  }
  static async handleOAuthCallback(provider, profile, accessToken, refreshToken, state) {
    let email = "";
    let firstName = "";
    let lastName = "";
    let profileImage = "";
    let oauthId = "";
    if (provider === "google") {
      email = profile.emails?.[0]?.value || "";
      firstName = profile.name?.givenName || "";
      lastName = profile.name?.familyName || "";
      profileImage = profile.photos?.[0]?.value || "";
      oauthId = profile.id;
    } else if (provider === "microsoft") {
      email = profile.emails?.[0]?.value || profile.username || "";
      firstName = profile.name?.givenName || "";
      lastName = profile.name?.familyName || "";
      profileImage = profile.photos?.[0]?.value || "";
      oauthId = profile.id;
    }
    if (!email || !oauthId) {
      throw new Error("Invalid OAuth profile data");
    }
    let user = await storage.getUserByEmail(email);
    if (!user) {
      user = await storage.getUserByOAuthId(provider, oauthId);
    }
    if (user) {
      if (user.authProvider === "local" || user.oauthId !== oauthId) {
        user = await storage.updateUser(user.id, {
          authProvider: provider,
          oauthId,
          profileImage: profileImage || user.profileImage,
          firstName: firstName || user.firstName,
          lastName: lastName || user.lastName
        });
      }
    } else {
      const userData = {
        username: email.split("@")[0] + "_" + Date.now(),
        // Generate unique username
        email,
        authProvider: provider,
        oauthId,
        profileImage,
        firstName,
        lastName,
        role: "user"
      };
      user = await storage.createOAuthUser(userData);
    }
    if (!user) {
      throw new Error("Failed to create or update user");
    }
    const token = import_jsonwebtoken.default.sign({ userId: user.id }, getJwtSecretAtRuntime(), { expiresIn: "7d" });
    const authResult = {
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
        profileImage: user.profileImage
      }
    };
    const sessionValid = await _OAuthService.validateAndCompleteOAuthSession(state, authResult);
    if (!sessionValid) {
      throw new Error("Invalid or expired OAuth session");
    }
    return { sessionState: state, authResult };
  }
  static getAvailableProviders() {
    return Object.values(OAUTH_PROVIDERS).filter(
      (provider) => provider.clientId && provider.clientSecret
    );
  }
  static isProviderConfigured(provider) {
    const config = OAUTH_PROVIDERS[provider];
    return !!(config && config.clientId && config.clientSecret);
  }
};

// server/routes.ts
var getJwtSecretAtRuntime2 = () => getJwtSecret();
var wsClients = /* @__PURE__ */ new Map();
async function broadcastERPStatusUpdate(userId) {
  const wsClient = wsClients.get(userId);
  if (wsClient && wsClient.readyState === import_ws2.WebSocket.OPEN) {
    try {
      const systems = await erpService.getConnectedSystems(userId);
      wsClient.send(JSON.stringify({
        type: "erp_status_update",
        data: systems.map((system) => ({
          name: system.name,
          displayName: system.displayName,
          description: system.description,
          isConnected: system.isConnected,
          lastSync: system.lastSync,
          status: system.isConnected ? "active" : "inactive"
        }))
      }));
    } catch (error) {
      console.error("Error broadcasting ERP status update:", error);
    }
  }
}
async function registerRoutes(app2, options = {}) {
  OAuthService.setupStrategies();
  app2.use(import_passport2.default.initialize());
  setInterval(async () => {
    try {
      await storage.cleanupExpiredOAuthSessions();
    } catch (error) {
      console.error("OAuth session cleanup error:", error);
    }
  }, 5 * 60 * 1e3);
  const authenticateToken = async (req, res, next) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (!token) {
      return res.status(401).json({ message: "Access token required" });
    }
    try {
      const decoded = import_jsonwebtoken2.default.verify(token, getJwtSecretAtRuntime2());
      const user = await storage.getUser(decoded.userId);
      if (!user) {
        return res.status(403).json({ message: "Invalid token" });
      }
      req.user = user;
      next();
    } catch (error) {
      return res.status(403).json({ message: "Invalid token" });
    }
  };
  app2.post("/api/auth/register", async (req, res) => {
    try {
      const { username, email, password } = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
      if (!password) {
        return res.status(400).json({ message: "Password is required for registration" });
      }
      const hashedPassword = await import_bcrypt.default.hash(password, 10);
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        authProvider: "local",
        role: "user"
      });
      const token = import_jsonwebtoken2.default.sign({ userId: user.id }, getJwtSecretAtRuntime2(), { expiresIn: "7d" });
      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, role: user.role }
      });
    } catch (error) {
      res.status(400).json({ message: "Registration failed", error: error.message });
    }
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      if (user.authProvider !== "local" || !user.password) {
        return res.status(401).json({ message: "Please use OAuth login for this account" });
      }
      const isValidPassword = await import_bcrypt.default.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const token = import_jsonwebtoken2.default.sign({ userId: user.id }, getJwtSecretAtRuntime2(), { expiresIn: "7d" });
      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, role: user.role }
      });
    } catch (error) {
      res.status(400).json({ message: "Login failed", error: error.message });
    }
  });
  app2.get("/api/oauth/providers", async (req, res) => {
    try {
      const providers = OAuthService.getAvailableProviders();
      res.json(providers.map((p) => ({
        name: p.name,
        displayName: p.displayName
      })));
    } catch (error) {
      res.status(500).json({ message: "Failed to get OAuth providers", error: error.message });
    }
  });
  app2.get("/api/auth/oauth-result/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const authResult = await OAuthService.getCompletedOAuthSession(sessionId);
      if (!authResult) {
        return res.status(404).json({ message: "OAuth session not found or expired" });
      }
      res.json(authResult);
    } catch (error) {
      console.error("OAuth session retrieval error:", error);
      res.status(500).json({ message: "Failed to retrieve OAuth result", error: error.message });
    }
  });
  app2.get("/api/auth/google", async (req, res, next) => {
    try {
      if (!OAuthService.isProviderConfigured("google")) {
        return res.status(503).json({
          message: "Google OAuth is not configured",
          error: "service_unavailable",
          details: {
            description: "Google OAuth authentication is not available because the required environment variables are not set.",
            required_variables: ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
            instructions: "Please contact your administrator to configure Google OAuth credentials."
          }
        });
      }
      const state = OAuthService.generateSecureState();
      await OAuthService.createOAuthSession("google", state);
      import_passport2.default.authenticate("google", {
        scope: ["profile", "email"],
        state
      })(req, res, next);
    } catch (error) {
      console.error("Google OAuth initiation error:", error);
      res.redirect("/login?error=oauth_failed");
    }
  });
  app2.get(
    "/api/auth/google/callback",
    import_passport2.default.authenticate("google", { session: false, failureRedirect: "/login?error=oauth_failed" }),
    async (req, res) => {
      try {
        const result = req.user;
        res.redirect(`/login?oauth_session=${result.sessionState}`);
      } catch (error) {
        console.error("Google OAuth callback error:", error);
        res.redirect("/login?error=oauth_failed");
      }
    }
  );
  app2.get("/api/auth/microsoft", async (req, res, next) => {
    try {
      if (!OAuthService.isProviderConfigured("microsoft")) {
        return res.status(503).json({
          message: "Microsoft OAuth is not configured",
          error: "service_unavailable",
          details: {
            description: "Microsoft OAuth authentication is not available because the required environment variables are not set.",
            required_variables: ["MICROSOFT_CLIENT_ID", "MICROSOFT_CLIENT_SECRET"],
            instructions: "Please contact your administrator to configure Microsoft OAuth credentials."
          }
        });
      }
      const state = OAuthService.generateSecureState();
      await OAuthService.createOAuthSession("microsoft", state);
      import_passport2.default.authenticate("microsoft", {
        scope: ["openid", "profile", "email", "offline_access", "User.Read"],
        state
      })(req, res, next);
    } catch (error) {
      console.error("Microsoft OAuth initiation error:", error);
      res.redirect("/login?error=oauth_failed");
    }
  });
  app2.get(
    "/api/auth/microsoft/callback",
    import_passport2.default.authenticate("microsoft", { session: false, failureRedirect: "/login?error=oauth_failed" }),
    async (req, res) => {
      try {
        const result = req.user;
        res.redirect(`/login?oauth_session=${result.sessionState}`);
      } catch (error) {
        console.error("Microsoft OAuth callback error:", error);
        res.redirect("/login?error=oauth_failed");
      }
    }
  );
  app2.get("/api/erp/systems", authenticateToken, async (req, res) => {
    try {
      const systems = await erpService.getConnectedSystems(req.user.id);
      res.json(systems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ERP systems", error: error.message });
    }
  });
  app2.post("/api/erp/connect/:system", authenticateToken, async (req, res) => {
    try {
      const { system } = req.params;
      const redirectUri = process.env.OAUTH_REDIRECT_URI || `${req.protocol}://${req.get("host")}/api/erp/callback`;
      const authUrl = await erpService.initiateOAuthFlow(system, req.user.id, redirectUri);
      res.json({ authUrl });
    } catch (error) {
      res.status(400).json({ message: "Failed to initiate OAuth", error: error.message });
    }
  });
  app2.get("/api/erp/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      if (!code || !state) {
        return res.status(400).json({ message: "Missing code or state parameter" });
      }
      const connection = await erpService.handleOAuthCallback(code, state);
      await broadcastERPStatusUpdate(connection.userId);
      res.redirect(`${process.env.FRONTEND_URL || "http://localhost:5000"}/dashboard?connected=${connection.erpSystem}`);
    } catch (error) {
      res.status(400).json({ message: "OAuth callback failed", error: error.message });
    }
  });
  app2.delete("/api/erp/disconnect/:system", authenticateToken, async (req, res) => {
    try {
      const { system } = req.params;
      await erpService.disconnectSystem(req.user.id, system);
      await broadcastERPStatusUpdate(req.user.id);
      res.json({ message: "System disconnected successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to disconnect system", error: error.message });
    }
  });
  app2.get("/api/erp/data", authenticateToken, async (req, res) => {
    try {
      const data = await erpService.aggregateERPData(req.user.id);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ERP data", error: error.message });
    }
  });
  app2.get("/api/kpis", authenticateToken, async (req, res) => {
    try {
      const kpis = await storage.getKpiConfigurations(req.user.id);
      const kpisWithData = await Promise.all(
        kpis.map(async (kpi) => {
          const latestData = await storage.getLatestKpiData(kpi.id);
          return { ...kpi, latestData };
        })
      );
      res.json(kpisWithData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch KPIs", error: error.message });
    }
  });
  app2.post("/api/kpis", authenticateToken, async (req, res) => {
    try {
      const kpiData2 = insertKpiConfigurationSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      const kpi = await storage.createKpiConfiguration(kpiData2);
      res.json(kpi);
    } catch (error) {
      res.status(400).json({ message: "Failed to create KPI", error: error.message });
    }
  });
  app2.put("/api/kpis/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const kpi = await storage.updateKpiConfiguration(id, updates);
      if (!kpi) {
        return res.status(404).json({ message: "KPI not found" });
      }
      res.json(kpi);
    } catch (error) {
      res.status(400).json({ message: "Failed to update KPI", error: error.message });
    }
  });
  app2.delete("/api/kpis/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteKpiConfiguration(id);
      if (!success) {
        return res.status(404).json({ message: "KPI not found" });
      }
      res.json({ message: "KPI deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete KPI", error: error.message });
    }
  });
  app2.get("/api/email/providers", authenticateToken, async (req, res) => {
    try {
      const configurations = await emailService.getEmailConfigurations(req.user.id);
      res.json({ configurations, providers: Object.values(emailService.getEmailTemplates()) });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch email providers", error: error.message });
    }
  });
  app2.post("/api/email/connect/:provider", authenticateToken, async (req, res) => {
    try {
      const { provider } = req.params;
      const redirectUri = process.env.EMAIL_OAUTH_REDIRECT_URI || `${req.protocol}://${req.get("host")}/api/email/callback`;
      const authUrl = await emailService.initiateEmailOAuth(provider, req.user.id, redirectUri);
      res.json({ authUrl });
    } catch (error) {
      res.status(400).json({ message: "Failed to initiate email OAuth", error: error.message });
    }
  });
  app2.get("/api/email/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      if (!code || !state) {
        return res.status(400).json({ message: "Missing code or state parameter" });
      }
      const config = await emailService.handleEmailOAuthCallback(code, state);
      res.redirect(`${process.env.FRONTEND_URL || "http://localhost:5000"}/dashboard?email_connected=${config.provider}`);
    } catch (error) {
      res.status(400).json({ message: "Email OAuth callback failed", error: error.message });
    }
  });
  app2.post("/api/email/send", authenticateToken, async (req, res) => {
    try {
      const { provider, to, subject, body, template, templateVariables } = req.body;
      let emailMessage = { to: Array.isArray(to) ? to : [to], subject, body };
      if (template) {
        const templates = emailService.getEmailTemplates();
        const emailTemplate = templates[template];
        if (emailTemplate) {
          const rendered = emailService.renderTemplate(emailTemplate, templateVariables || {});
          emailMessage.subject = rendered.subject;
          emailMessage.body = rendered.body;
        }
      }
      const success = await emailService.sendEmail(req.user.id, provider, emailMessage);
      if (success) {
        res.json({ message: "Email sent successfully" });
      } else {
        res.status(500).json({ message: "Failed to send email" });
      }
    } catch (error) {
      res.status(400).json({ message: "Failed to send email", error: error.message });
    }
  });
  app2.post("/api/chat/query", authenticateToken, async (req, res) => {
    try {
      const { query } = req.body;
      const erpData = await erpService.aggregateERPData(req.user.id);
      const response = await analyzeERPData({
        query,
        erpData,
        userId: req.user.id
      });
      await storage.createChatHistory({
        userId: req.user.id,
        query,
        response: response.response,
        erpData
      });
      const wsClient = wsClients.get(req.user.id);
      if (wsClient && wsClient.readyState === import_ws2.WebSocket.OPEN) {
        wsClient.send(JSON.stringify({
          type: "chat_response",
          data: response
        }));
      }
      res.json(response);
    } catch (error) {
      res.status(500).json({ message: "Failed to process query", error: error.message });
    }
  });
  app2.get("/api/chat/history", authenticateToken, async (req, res) => {
    try {
      const history = await storage.getChatHistory(req.user.id);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat history", error: error.message });
    }
  });
  app2.get("/api/insights", authenticateToken, async (req, res) => {
    try {
      const kpis = await storage.getKpiConfigurations(req.user.id);
      const kpiData2 = {};
      for (const kpi of kpis) {
        const latestData = await storage.getLatestKpiData(kpi.id);
        if (latestData) {
          kpiData2[kpi.name] = {
            value: latestData.value,
            change: latestData.change,
            type: kpi.type
          };
        }
      }
      const insights = await generateKPIInsights(kpiData2);
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate insights", error: error.message });
    }
  });
  const httpServer = (0, import_http.createServer)(app2);
  if (!options.excludeWebSocket) {
    const wss = new import_ws2.WebSocketServer({ server: httpServer, path: "/ws" });
    wss.on("connection", (ws2, req) => {
      console.log("WebSocket client connected");
      ws2.on("message", async (data) => {
        try {
          const message = JSON.parse(data.toString());
          if (message.type === "auth" && message.token) {
            try {
              const decoded = import_jsonwebtoken2.default.verify(message.token, getJwtSecret());
              const user = await storage.getUser(decoded.userId);
              if (user) {
                wsClients.set(user.id, ws2);
                ws2.send(JSON.stringify({ type: "auth_success", userId: user.id }));
              }
            } catch (error) {
              ws2.send(JSON.stringify({ type: "auth_error", message: "Invalid token" }));
            }
          }
        } catch (error) {
          console.error("WebSocket message error:", error);
        }
      });
      ws2.on("close", () => {
        for (const [userId, client] of Array.from(wsClients.entries())) {
          if (client === ws2) {
            wsClients.delete(userId);
            break;
          }
        }
      });
    });
    setInterval(async () => {
      for (const [userId, ws2] of Array.from(wsClients.entries())) {
        if (ws2.readyState === import_ws2.WebSocket.OPEN) {
          try {
            const kpis = await storage.getKpiConfigurations(userId);
            const kpiUpdates = [];
            for (const kpi of kpis.slice(0, 5)) {
              const latestData = await storage.getLatestKpiData(kpi.id);
              if (latestData) {
                kpiUpdates.push({
                  id: kpi.id,
                  name: kpi.name,
                  type: kpi.type,
                  value: latestData.value,
                  change: latestData.change,
                  timestamp: latestData.timestamp
                });
              }
            }
            if (kpiUpdates.length > 0) {
              ws2.send(JSON.stringify({
                type: "kpi_update",
                data: kpiUpdates
              }));
            }
          } catch (error) {
            console.error("Error sending KPI updates:", error);
          }
        }
      }
    }, 3e4);
  }
  return httpServer;
}

// server/lambda.ts
enforceEnvironmentValidation();
var app = (0, import_express.default)();
app.set("trust proxy", true);
app.use(import_express.default.json());
app.use(import_express.default.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      console.log(`${req.method} ${path} ${res.statusCode} in ${duration}ms`);
    }
  });
  next();
});
var isInitialized = false;
var initializationPromise = null;
async function initializeAppOnce() {
  if (isInitialized) {
    return;
  }
  if (initializationPromise) {
    return initializationPromise;
  }
  initializationPromise = (async () => {
    try {
      const httpServer = await registerRoutes(app, { excludeWebSocket: true });
      app.use((err, _req, res, _next) => {
        const status = err.status || err.statusCode || 500;
        const message = err.message || "Internal Server Error";
        res.status(status).json({ message });
        console.error(err);
      });
      app.get("/health", (req, res) => {
        res.json({
          status: "healthy",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          environment: process.env.NODE_ENV || "development"
        });
      });
      isInitialized = true;
      console.log("Lambda app initialized successfully");
    } catch (error) {
      console.error("Failed to initialize Lambda app:", error);
      initializationPromise = null;
      throw error;
    }
  })();
  return initializationPromise;
}
var serverlessHandler = (0, import_serverless_http.default)(app, {
  binary: ["image/*", "application/pdf", "application/octet-stream"],
  request(request, event, context) {
    request.awsEvent = event;
    request.awsContext = context;
  },
  response(response, event, context) {
    const allowedOrigin = "https://d2k9wjgsy12ugk.cloudfront.net";
    response.headers = response.headers || {};
    response.headers["Access-Control-Allow-Origin"] = allowedOrigin;
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization,Accept,Origin,X-Requested-With";
    response.headers["Access-Control-Allow-Methods"] = "GET,HEAD,POST,PUT,DELETE,OPTIONS,PATCH";
    response.headers["Access-Control-Allow-Credentials"] = "false";
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
    response.headers["Pragma"] = "no-cache";
    response.headers["Expires"] = "0";
  }
});
var handler = async (event, context, callback) => {
  await initializeAppOnce();
  return serverlessHandler(event, context, callback);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
