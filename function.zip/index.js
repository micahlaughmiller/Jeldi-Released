var __defProp = Object.defineProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  auditLog: () => auditLog,
  auditLogRelations: () => auditLogRelations,
  chatHistory: () => chatHistory,
  chatHistoryRelations: () => chatHistoryRelations,
  conversationRelations: () => conversationRelations,
  conversations: () => conversations,
  emailConfigurationRelations: () => emailConfigurationRelations,
  emailConfigurations: () => emailConfigurations,
  emailProviderParamsSchema: () => emailProviderParamsSchema,
  emailSendRequestSchema: () => emailSendRequestSchema,
  erpConnectionRelations: () => erpConnectionRelations,
  erpConnections: () => erpConnections,
  favoriteQueries: () => favoriteQueries,
  favoriteQueryRelations: () => favoriteQueryRelations,
  insertAuditLogSchema: () => insertAuditLogSchema,
  insertChatHistorySchema: () => insertChatHistorySchema,
  insertConversationSchema: () => insertConversationSchema,
  insertEmailConfigurationSchema: () => insertEmailConfigurationSchema,
  insertErpConnectionSchema: () => insertErpConnectionSchema,
  insertFavoriteQuerySchema: () => insertFavoriteQuerySchema,
  insertKpiConfigurationSchema: () => insertKpiConfigurationSchema,
  insertKpiDataSchema: () => insertKpiDataSchema,
  insertOAuthSessionSchema: () => insertOAuthSessionSchema,
  insertOAuthUserSchema: () => insertOAuthUserSchema,
  insertPermissionSchema: () => insertPermissionSchema,
  insertQueryTemplateSchema: () => insertQueryTemplateSchema,
  insertRolePermissionSchema: () => insertRolePermissionSchema,
  insertRoleSchema: () => insertRoleSchema,
  insertUserPreferencesSchema: () => insertUserPreferencesSchema,
  insertUserRoleSchema: () => insertUserRoleSchema,
  insertUserSchema: () => insertUserSchema,
  kpiConfigurationRelations: () => kpiConfigurationRelations,
  kpiConfigurations: () => kpiConfigurations,
  kpiData: () => kpiData,
  kpiDataRelations: () => kpiDataRelations,
  oauthSessions: () => oauthSessions,
  permissionCheckSchema: () => permissionCheckSchema,
  permissionRelations: () => permissionRelations,
  permissions: () => permissions,
  queryTemplateRelations: () => queryTemplateRelations,
  queryTemplates: () => queryTemplates,
  roleAssignmentSchema: () => roleAssignmentSchema,
  rolePermissionRelations: () => rolePermissionRelations,
  rolePermissions: () => rolePermissions,
  roleRelations: () => roleRelations,
  roleRevocationSchema: () => roleRevocationSchema,
  roles: () => roles,
  smtpConfigRequestSchema: () => smtpConfigRequestSchema,
  updateRoleSchema: () => updateRoleSchema,
  updateUserPreferencesSchema: () => updateUserPreferencesSchema,
  updateUserRoleSchema: () => updateUserRoleSchema,
  userPreferences: () => userPreferences,
  userPreferencesRelations: () => userPreferencesRelations,
  userRelations: () => userRelations,
  userRoleRelations: () => userRoleRelations,
  userRoles: () => userRoles,
  users: () => users2
});
import { sql as sql2 } from "drizzle-orm";
import { pgTable, text, timestamp, jsonb, boolean, integer, decimal, uuid } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var users2 = pgTable("users", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password"),
  // Optional for OAuth users
  role: text("role").notNull().default("user"),
  // OAuth authentication fields
  authProvider: text("auth_provider").default("local"),
  // local, google, microsoft
  oauthId: text("oauth_id"),
  // OAuth provider user ID
  profileImage: text("profile_image"),
  // OAuth profile image URL
  firstName: text("first_name"),
  // OAuth first name
  lastName: text("last_name"),
  // OAuth last name
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var erpConnections = pgTable("erp_connections", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id).notNull(),
  erpSystem: text("erp_system").notNull(),
  // SAP, NetSuite, Dynamics365, etc.
  isConnected: boolean("is_connected").default(false).notNull(),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiry: timestamp("token_expiry"),
  config: jsonb("config"),
  // OAuth config and endpoints
  lastSync: timestamp("last_sync"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var kpiConfigurations = pgTable("kpi_configurations", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id).notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  // revenue, orders, inventory, performance, efficiency
  erpSource: text("erp_source").notNull(),
  query: text("query").notNull(),
  // SQL or API query for data
  position: integer("position").notNull(),
  // Dashboard position 1-5
  isActive: boolean("is_active").default(true).notNull(),
  refreshInterval: integer("refresh_interval").default(30).notNull(),
  // seconds
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var kpiData = pgTable("kpi_data", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  kpiId: uuid("kpi_id").references(() => kpiConfigurations.id).notNull(),
  value: text("value").notNull(),
  change: decimal("change", { precision: 5, scale: 2 }),
  timestamp: timestamp("timestamp").defaultNow().notNull()
});
var emailConfigurations = pgTable("email_configurations", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id).notNull(),
  provider: text("provider").notNull(),
  // gmail, outlook, smtp
  email: text("email").notNull(),
  accessToken: text("access_token"),
  // encrypted
  refreshToken: text("refresh_token"),
  // encrypted
  tokenExpiry: timestamp("token_expiry"),
  scopes: text("scopes").array().default(sql2`'{}'`),
  // OAuth scopes granted
  isActive: boolean("is_active").default(true).notNull(),
  lastUsed: timestamp("last_used"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
var oauthSessions = pgTable("oauth_sessions", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  state: text("state").notNull().unique(),
  // CSRF protection state
  provider: text("provider").notNull(),
  // google, microsoft
  isCompleted: boolean("is_completed").default(false).notNull(),
  authResult: jsonb("auth_result"),
  // Temporary storage for JWT and user data
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var conversations = pgTable("conversations", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  isFavorite: boolean("is_favorite").default(false).notNull(),
  lastMessageAt: timestamp("last_message_at").defaultNow().notNull(),
  messageCount: integer("message_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
var chatHistory = pgTable("chat_history", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  conversationId: uuid("conversation_id").references(() => conversations.id).notNull(),
  userId: uuid("user_id").references(() => users2.id).notNull(),
  query: text("query").notNull(),
  response: text("response").notNull(),
  insights: text("insights").array().default(sql2`'{}'`),
  recommendations: text("recommendations").array().default(sql2`'{}'`),
  dataUsed: text("data_used").array().default(sql2`'{}'`),
  erpData: jsonb("erp_data"),
  // Context data used for the query
  responseTime: integer("response_time"),
  // milliseconds
  timestamp: timestamp("timestamp").defaultNow().notNull()
});
var queryTemplates = pgTable("query_templates", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  query: text("query").notNull(),
  category: text("category").notNull(),
  // financial, operational, performance, inventory, etc.
  icon: text("icon").notNull(),
  isSystem: boolean("is_system").default(true).notNull(),
  // system templates vs user-created
  userId: uuid("user_id").references(() => users2.id),
  // null for system templates
  usageCount: integer("usage_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var favoriteQueries = pgTable("favorite_queries", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id).notNull(),
  query: text("query").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  usageCount: integer("usage_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var userPreferences = pgTable("user_preferences", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id).notNull().unique(),
  // Theme & Appearance
  theme: text("theme").default("light").notNull(),
  // light, dark, system
  sidebarCollapsed: boolean("sidebar_collapsed").default(false).notNull(),
  // Localization
  language: text("language").default("en").notNull(),
  // en, es, fr, de, etc.
  timezone: text("timezone").default("UTC").notNull(),
  dateFormat: text("date_format").default("MM/dd/yyyy").notNull(),
  // MM/dd/yyyy, dd/MM/yyyy, yyyy-MM-dd
  timeFormat: text("time_format").default("12h").notNull(),
  // 12h, 24h  
  currency: text("currency").default("USD").notNull(),
  // USD, EUR, GBP, etc.
  // Notifications
  emailNotifications: boolean("email_notifications").default(true).notNull(),
  pushNotifications: boolean("push_notifications").default(true).notNull(),
  weeklyReports: boolean("weekly_reports").default(true).notNull(),
  systemAlerts: boolean("system_alerts").default(true).notNull(),
  // Dashboard Preferences
  defaultDashboard: text("default_dashboard").default("overview").notNull(),
  // overview, analytics, custom
  refreshInterval: integer("refresh_interval").default(30).notNull(),
  // seconds
  showTutorials: boolean("show_tutorials").default(true).notNull(),
  // Privacy & Security
  sessionTimeout: integer("session_timeout").default(30).notNull(),
  // minutes
  twoFactorEnabled: boolean("two_factor_enabled").default(false).notNull(),
  // Data & Export
  dataRetention: integer("data_retention").default(365).notNull(),
  // days
  exportFormat: text("export_format").default("csv").notNull(),
  // csv, json, xlsx
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
var roles = pgTable("roles", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  // admin, ops_manager, finance, cfo, project_manager, cost_manager, sales, marketing
  displayName: text("display_name").notNull(),
  // Human-readable name
  description: text("description"),
  // Role description
  color: text("color").default("#6366f1").notNull(),
  // UI color for role badges
  isSystem: boolean("is_system").default(true).notNull(),
  // System roles vs custom roles
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
var permissions = pgTable("permissions", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  // e.g., user.create, financial.view, erp.manage
  displayName: text("display_name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  // user_management, financial_data, erp_access, ai_assistant, dashboard, settings
  resource: text("resource").notNull(),
  // users, kpis, erp_connections, email_configs, etc.
  action: text("action").notNull(),
  // create, read, update, delete, manage
  isSystem: boolean("is_system").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var userRoles = pgTable("user_roles", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id).notNull(),
  roleId: uuid("role_id").references(() => roles.id).notNull(),
  assignedBy: uuid("assigned_by").references(() => users2.id),
  // Who assigned this role
  assignedAt: timestamp("assigned_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
  // Optional role expiration
  isActive: boolean("is_active").default(true).notNull()
});
var rolePermissions = pgTable("role_permissions", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  roleId: uuid("role_id").references(() => roles.id).notNull(),
  permissionId: uuid("permission_id").references(() => permissions.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var auditLog = pgTable("audit_log", {
  id: uuid("id").primaryKey().default(sql2`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users2.id),
  action: text("action").notNull(),
  // role.assigned, role.revoked, permission.granted, etc.
  resource: text("resource").notNull(),
  // Table or entity affected
  resourceId: text("resource_id"),
  // ID of the affected resource
  oldValue: jsonb("old_value"),
  // Previous state
  newValue: jsonb("new_value"),
  // New state
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow().notNull()
});
var userRelations = relations(users2, ({ many, one }) => ({
  erpConnections: many(erpConnections),
  kpiConfigurations: many(kpiConfigurations),
  emailConfigurations: many(emailConfigurations),
  conversations: many(conversations),
  chatHistory: many(chatHistory),
  queryTemplates: many(queryTemplates),
  favoriteQueries: many(favoriteQueries),
  preferences: one(userPreferences),
  // RBAC relations
  userRoles: many(userRoles),
  assignedRoles: many(userRoles, { relationName: "assigned_roles" }),
  auditLogs: many(auditLog)
}));
var conversationRelations = relations(conversations, ({ one, many }) => ({
  user: one(users2, {
    fields: [conversations.userId],
    references: [users2.id]
  }),
  messages: many(chatHistory)
}));
var queryTemplateRelations = relations(queryTemplates, ({ one }) => ({
  user: one(users2, {
    fields: [queryTemplates.userId],
    references: [users2.id]
  })
}));
var favoriteQueryRelations = relations(favoriteQueries, ({ one }) => ({
  user: one(users2, {
    fields: [favoriteQueries.userId],
    references: [users2.id]
  })
}));
var erpConnectionRelations = relations(erpConnections, ({ one }) => ({
  user: one(users2, {
    fields: [erpConnections.userId],
    references: [users2.id]
  })
}));
var kpiConfigurationRelations = relations(kpiConfigurations, ({ one, many }) => ({
  user: one(users2, {
    fields: [kpiConfigurations.userId],
    references: [users2.id]
  }),
  data: many(kpiData)
}));
var kpiDataRelations = relations(kpiData, ({ one }) => ({
  kpi: one(kpiConfigurations, {
    fields: [kpiData.kpiId],
    references: [kpiConfigurations.id]
  })
}));
var emailConfigurationRelations = relations(emailConfigurations, ({ one }) => ({
  user: one(users2, {
    fields: [emailConfigurations.userId],
    references: [users2.id]
  })
}));
var chatHistoryRelations = relations(chatHistory, ({ one }) => ({
  user: one(users2, {
    fields: [chatHistory.userId],
    references: [users2.id]
  }),
  conversation: one(conversations, {
    fields: [chatHistory.conversationId],
    references: [conversations.id]
  })
}));
var userPreferencesRelations = relations(userPreferences, ({ one }) => ({
  user: one(users2, {
    fields: [userPreferences.userId],
    references: [users2.id]
  })
}));
var roleRelations = relations(roles, ({ many }) => ({
  userRoles: many(userRoles),
  rolePermissions: many(rolePermissions)
}));
var permissionRelations = relations(permissions, ({ many }) => ({
  rolePermissions: many(rolePermissions)
}));
var userRoleRelations = relations(userRoles, ({ one }) => ({
  user: one(users2, {
    fields: [userRoles.userId],
    references: [users2.id]
  }),
  role: one(roles, {
    fields: [userRoles.roleId],
    references: [roles.id]
  }),
  assignedByUser: one(users2, {
    fields: [userRoles.assignedBy],
    references: [users2.id],
    relationName: "assigned_roles"
  })
}));
var rolePermissionRelations = relations(rolePermissions, ({ one }) => ({
  role: one(roles, {
    fields: [rolePermissions.roleId],
    references: [roles.id]
  }),
  permission: one(permissions, {
    fields: [rolePermissions.permissionId],
    references: [permissions.id]
  })
}));
var auditLogRelations = relations(auditLog, ({ one }) => ({
  user: one(users2, {
    fields: [auditLog.userId],
    references: [users2.id]
  })
}));
var insertUserSchema = createInsertSchema(users2).omit({
  id: true,
  createdAt: true
}).extend({
  password: z.string().min(8).optional()
  // Make password optional for OAuth
});
var insertOAuthUserSchema = createInsertSchema(users2).omit({
  id: true,
  createdAt: true,
  password: true
  // OAuth users don't need passwords
});
var insertErpConnectionSchema = createInsertSchema(erpConnections).omit({
  id: true,
  createdAt: true
});
var insertKpiConfigurationSchema = createInsertSchema(kpiConfigurations).omit({
  id: true,
  createdAt: true
});
var insertKpiDataSchema = createInsertSchema(kpiData).omit({
  id: true,
  timestamp: true
});
var insertEmailConfigurationSchema = createInsertSchema(emailConfigurations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastUsed: true
});
var insertOAuthSessionSchema = createInsertSchema(oauthSessions).omit({
  id: true,
  createdAt: true
});
var insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastMessageAt: true,
  messageCount: true
});
var insertChatHistorySchema = createInsertSchema(chatHistory).omit({
  id: true,
  timestamp: true
});
var insertQueryTemplateSchema = createInsertSchema(queryTemplates).omit({
  id: true,
  createdAt: true,
  usageCount: true
});
var insertFavoriteQuerySchema = createInsertSchema(favoriteQueries).omit({
  id: true,
  createdAt: true,
  usageCount: true
});
var insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var updateUserPreferencesSchema = insertUserPreferencesSchema.omit({
  userId: true
}).partial();
var insertRoleSchema = createInsertSchema(roles).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertPermissionSchema = createInsertSchema(permissions).omit({
  id: true,
  createdAt: true
});
var insertUserRoleSchema = createInsertSchema(userRoles).omit({
  id: true,
  assignedAt: true
});
var insertRolePermissionSchema = createInsertSchema(rolePermissions).omit({
  id: true,
  createdAt: true
});
var insertAuditLogSchema = createInsertSchema(auditLog).omit({
  id: true,
  timestamp: true
});
var updateRoleSchema = insertRoleSchema.omit({
  name: true
}).partial();
var updateUserRoleSchema = insertUserRoleSchema.omit({
  userId: true,
  roleId: true
}).partial();
var roleAssignmentSchema = z.object({
  userId: z.string().uuid(),
  roleId: z.string().uuid(),
  expiresAt: z.date().optional()
});
var roleRevocationSchema = z.object({
  userId: z.string().uuid(),
  roleId: z.string().uuid()
});
var permissionCheckSchema = z.object({
  resource: z.string(),
  action: z.string()
});
var emailSchema = z.string().email({ message: "Invalid email address" });
var emailArraySchema = z.array(emailSchema).min(1, { message: "At least one email address required" });
var providerSchema = z.enum(["gmail", "outlook", "smtp"], { message: "Invalid email provider" });
var emailSendRequestSchema = z.object({
  provider: providerSchema,
  to: z.union([emailSchema, emailArraySchema]).transform((val) => Array.isArray(val) ? val : [val]),
  cc: z.union([emailSchema, emailArraySchema]).transform((val) => Array.isArray(val) ? val : [val]).optional(),
  bcc: z.union([emailSchema, emailArraySchema]).transform((val) => Array.isArray(val) ? val : [val]).optional(),
  subject: z.string().min(1, { message: "Subject is required" }).max(500, { message: "Subject too long" }).optional(),
  body: z.string().max(5e4, { message: "Email body too long" }).optional(),
  template: z.string().optional(),
  templateVariables: z.record(z.any()).optional(),
  isHtml: z.boolean().default(false)
}).refine((data) => data.subject || data.template, {
  message: "Either subject or template must be provided",
  path: ["subject"]
});
var smtpConfigRequestSchema = z.object({
  host: z.string().min(1, { message: "SMTP host is required" }),
  port: z.coerce.number().int().min(1).max(65535, { message: "Invalid port number" }),
  secure: z.union([
    z.boolean(),
    z.string().transform((val) => {
      if (val === "true" || val === "1") return true;
      if (val === "false" || val === "0") return false;
      throw new Error("Invalid secure value - must be true, false, 1, or 0");
    })
  ]).default(false),
  username: z.string().min(1, { message: "Username is required" }),
  password: z.string().min(1, { message: "Password is required" })
});
var emailProviderParamsSchema = z.object({
  provider: providerSchema
});

// server/db.ts
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
neonConfig.webSocketConstructor = ws;
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?"
  );
}
var pool = new Pool({ connectionString: process.env.DATABASE_URL });
var db2 = drizzle({ client: pool, schema: schema_exports });

// server/storage.ts
import { eq, desc, and, sql as sql3 } from "drizzle-orm";
var DatabaseStorage = class {
  async getUser(id) {
    const [user] = await db2.select().from(users2).where(eq(users2.id, id));
    return user || void 0;
  }
  async getUserByUsername(username) {
    const [user] = await db2.select().from(users2).where(eq(users2.username, username));
    return user || void 0;
  }
  async getUserByEmail(email) {
    const [user] = await db2.select().from(users2).where(eq(users2.email, email));
    return user || void 0;
  }
  async getUserCount() {
    const [result] = await db2.select({ count: sql3`count(*)` }).from(users2);
    return result.count;
  }
  async createUser(insertUser) {
    const [user] = await db2.insert(users2).values(insertUser).returning();
    return user;
  }
  async getUserByOAuthId(provider, oauthId) {
    const [user] = await db2.select().from(users2).where(and(eq(users2.authProvider, provider), eq(users2.oauthId, oauthId)));
    return user || void 0;
  }
  async createOAuthUser(insertOAuthUser) {
    const [user] = await db2.insert(users2).values(insertOAuthUser).returning();
    return user;
  }
  async updateUser(id, updates) {
    const [user] = await db2.update(users2).set(updates).where(eq(users2.id, id)).returning();
    return user || void 0;
  }
  async getErpConnections(userId) {
    return await db2.select().from(erpConnections).where(eq(erpConnections.userId, userId));
  }
  async getErpConnection(userId, erpSystem) {
    const [connection] = await db2.select().from(erpConnections).where(and(eq(erpConnections.userId, userId), eq(erpConnections.erpSystem, erpSystem)));
    return connection || void 0;
  }
  async createErpConnection(connection) {
    const [newConnection] = await db2.insert(erpConnections).values(connection).returning();
    return newConnection;
  }
  async updateErpConnection(id, updates) {
    const [updated] = await db2.update(erpConnections).set(updates).where(eq(erpConnections.id, id)).returning();
    return updated || void 0;
  }
  async getKpiConfigurations(userId) {
    return await db2.select().from(kpiConfigurations).where(eq(kpiConfigurations.userId, userId)).orderBy(kpiConfigurations.position);
  }
  async createKpiConfiguration(config) {
    const [newConfig] = await db2.insert(kpiConfigurations).values(config).returning();
    return newConfig;
  }
  async updateKpiConfiguration(id, updates) {
    const [updated] = await db2.update(kpiConfigurations).set(updates).where(eq(kpiConfigurations.id, id)).returning();
    return updated || void 0;
  }
  async deleteKpiConfiguration(id) {
    const result = await db2.delete(kpiConfigurations).where(eq(kpiConfigurations.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getLatestKpiData(kpiId) {
    const [data] = await db2.select().from(kpiData).where(eq(kpiData.kpiId, kpiId)).orderBy(desc(kpiData.timestamp)).limit(1);
    return data || void 0;
  }
  async createKpiData(data) {
    const [newData] = await db2.insert(kpiData).values(data).returning();
    return newData;
  }
  async getKpiDataHistory(kpiId, limit = 50) {
    return await db2.select().from(kpiData).where(eq(kpiData.kpiId, kpiId)).orderBy(desc(kpiData.timestamp)).limit(limit);
  }
  async getEmailConfigurations(userId) {
    return await db2.select().from(emailConfigurations).where(eq(emailConfigurations.userId, userId));
  }
  async createEmailConfiguration(config) {
    const [newConfig] = await db2.insert(emailConfigurations).values(config).returning();
    return newConfig;
  }
  async updateEmailConfiguration(id, updates) {
    const [updated] = await db2.update(emailConfigurations).set(updates).where(eq(emailConfigurations.id, id)).returning();
    return updated || void 0;
  }
  async getChatHistory(userId, limit = 50) {
    return await db2.select().from(chatHistory).where(eq(chatHistory.userId, userId)).orderBy(desc(chatHistory.timestamp)).limit(limit);
  }
  async createChatHistory(chat) {
    const [newChat] = await db2.insert(chatHistory).values(chat).returning();
    return newChat;
  }
  async createOAuthSession(session) {
    const [newSession] = await db2.insert(oauthSessions).values(session).returning();
    return newSession;
  }
  async getOAuthSession(id) {
    const [session] = await db2.select().from(oauthSessions).where(eq(oauthSessions.id, id));
    return session || void 0;
  }
  async getOAuthSessionByState(state) {
    const [session] = await db2.select().from(oauthSessions).where(eq(oauthSessions.state, state));
    return session || void 0;
  }
  async updateOAuthSession(id, updates) {
    const [updated] = await db2.update(oauthSessions).set(updates).where(eq(oauthSessions.id, id)).returning();
    return updated || void 0;
  }
  async deleteOAuthSession(id) {
    const result = await db2.delete(oauthSessions).where(eq(oauthSessions.id, id));
    return (result.rowCount || 0) > 0;
  }
  async cleanupExpiredOAuthSessions() {
    await db2.delete(oauthSessions).where(sql3`${oauthSessions.expiresAt} < NOW()`);
  }
  async getUserPreferences(userId) {
    const [preferences] = await db2.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return preferences || void 0;
  }
  async createUserPreferences(preferences) {
    const [newPreferences] = await db2.insert(userPreferences).values(preferences).returning();
    return newPreferences;
  }
  async updateUserPreferences(userId, updates) {
    const [updated] = await db2.update(userPreferences).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq(userPreferences.userId, userId)).returning();
    return updated || void 0;
  }
  async resetUserPreferences(userId) {
    await db2.delete(userPreferences).where(eq(userPreferences.userId, userId));
    return await this.createUserPreferences({ userId });
  }
  // Conversation operations
  async getConversations(userId, limit = 50) {
    return await db2.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.lastMessageAt)).limit(limit);
  }
  async getConversation(id) {
    const [conversation] = await db2.select().from(conversations).where(eq(conversations.id, id));
    return conversation || void 0;
  }
  async createConversation(conversation) {
    const [newConversation] = await db2.insert(conversations).values(conversation).returning();
    return newConversation;
  }
  async updateConversation(id, updates) {
    const [updated] = await db2.update(conversations).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq(conversations.id, id)).returning();
    return updated || void 0;
  }
  async deleteConversation(id) {
    await db2.delete(chatHistory).where(eq(chatHistory.conversationId, id));
    const result = await db2.delete(conversations).where(eq(conversations.id, id));
    return (result.rowCount || 0) > 0;
  }
  // Enhanced Chat History operations
  async getChatHistoryByConversation(conversationId, limit = 100) {
    return await db2.select().from(chatHistory).where(eq(chatHistory.conversationId, conversationId)).orderBy(chatHistory.timestamp).limit(limit);
  }
  async deleteChatHistory(id) {
    const result = await db2.delete(chatHistory).where(eq(chatHistory.id, id));
    return (result.rowCount || 0) > 0;
  }
  // Query Template operations
  async getQueryTemplates(category) {
    if (category) {
      return await db2.select().from(queryTemplates).where(and(eq(queryTemplates.isSystem, true), eq(queryTemplates.category, category))).orderBy(desc(queryTemplates.usageCount));
    }
    return await db2.select().from(queryTemplates).where(eq(queryTemplates.isSystem, true)).orderBy(desc(queryTemplates.usageCount));
  }
  async getUserQueryTemplates(userId) {
    return await db2.select().from(queryTemplates).where(eq(queryTemplates.userId, userId)).orderBy(desc(queryTemplates.usageCount));
  }
  async createQueryTemplate(template) {
    const [newTemplate] = await db2.insert(queryTemplates).values(template).returning();
    return newTemplate;
  }
  async updateQueryTemplateUsage(id) {
    await db2.update(queryTemplates).set({ usageCount: sql3`${queryTemplates.usageCount} + 1` }).where(eq(queryTemplates.id, id));
  }
  // Favorite Query operations
  async getFavoriteQueries(userId, category) {
    if (category) {
      return await db2.select().from(favoriteQueries).where(and(eq(favoriteQueries.userId, userId), eq(favoriteQueries.category, category))).orderBy(desc(favoriteQueries.usageCount));
    }
    return await db2.select().from(favoriteQueries).where(eq(favoriteQueries.userId, userId)).orderBy(desc(favoriteQueries.usageCount));
  }
  async createFavoriteQuery(favorite) {
    const [newFavorite] = await db2.insert(favoriteQueries).values(favorite).returning();
    return newFavorite;
  }
  async deleteFavoriteQuery(id) {
    const result = await db2.delete(favoriteQueries).where(eq(favoriteQueries.id, id));
    return (result.rowCount || 0) > 0;
  }
  async updateFavoriteQueryUsage(id) {
    await db2.update(favoriteQueries).set({ usageCount: sql3`${favoriteQueries.usageCount} + 1` }).where(eq(favoriteQueries.id, id));
  }
  // User Preferences operations
  async getUserPreferences(userId) {
    const [preferences] = await db2.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return preferences || void 0;
  }
  async createUserPreferences(preferences) {
    const [newPreferences] = await db2.insert(userPreferences).values(preferences).returning();
    return newPreferences;
  }
  async updateUserPreferences(userId, updates) {
    const [updatedPreferences] = await db2.update(userPreferences).set(updates).where(eq(userPreferences.userId, userId)).returning();
    return updatedPreferences || void 0;
  }
  async resetUserPreferences(userId) {
    const [resetPreferences] = await db2.update(userPreferences).set({
      theme: "light",
      sidebarCollapsed: false,
      language: "en",
      timezone: "UTC",
      dateFormat: "MM/dd/yyyy",
      timeFormat: "12h",
      currency: "USD",
      emailNotifications: true,
      pushNotifications: true,
      weeklyReports: true,
      systemAlerts: true,
      defaultDashboard: "overview",
      refreshInterval: 30,
      showTutorials: true,
      sessionTimeout: 30,
      twoFactorEnabled: false,
      dataRetention: 365,
      exportFormat: "csv"
    }).where(eq(userPreferences.userId, userId)).returning();
    return resetPreferences || void 0;
  }
  // RBAC operations
  // Role operations
  async getRoles() {
    return await db2.select().from(roles).where(eq(roles.isActive, true)).orderBy(roles.displayName);
  }
  async getRole(id) {
    const [role] = await db2.select().from(roles).where(eq(roles.id, id));
    return role || void 0;
  }
  async getRoleByName(name) {
    const [role] = await db2.select().from(roles).where(eq(roles.name, name));
    return role || void 0;
  }
  async createRole(role) {
    const [newRole] = await db2.insert(roles).values(role).returning();
    return newRole;
  }
  async createRoleIfNotExists(role) {
    const existingRole = await this.getRoleByName(role.name);
    if (existingRole) {
      return existingRole;
    }
    return await this.createRole(role);
  }
  async updateRole(id, updates) {
    const [updatedRole] = await db2.update(roles).set(updates).where(eq(roles.id, id)).returning();
    return updatedRole || void 0;
  }
  async deleteRole(id) {
    const result = await db2.delete(roles).where(eq(roles.id, id));
    return (result.rowCount || 0) > 0;
  }
  // Permission operations
  async getPermissions() {
    return await db2.select().from(permissions).orderBy(permissions.category, permissions.displayName);
  }
  async getPermission(id) {
    const [permission] = await db2.select().from(permissions).where(eq(permissions.id, id));
    return permission || void 0;
  }
  async getPermissionByName(name) {
    const [permission] = await db2.select().from(permissions).where(eq(permissions.name, name));
    return permission || void 0;
  }
  async createPermission(permission) {
    const [newPermission] = await db2.insert(permissions).values(permission).returning();
    return newPermission;
  }
  async createPermissionIfNotExists(permission) {
    const existingPermission = await this.getPermissionByName(permission.name);
    if (existingPermission) {
      return existingPermission;
    }
    return await this.createPermission(permission);
  }
  async deletePermission(id) {
    const result = await db2.delete(permissions).where(eq(permissions.id, id));
    return (result.rowCount || 0) > 0;
  }
  // User Role operations
  async getUserRoles(userId) {
    return await db2.select({
      id: userRoles.id,
      userId: userRoles.userId,
      roleId: userRoles.roleId,
      assignedBy: userRoles.assignedBy,
      assignedAt: userRoles.assignedAt,
      expiresAt: userRoles.expiresAt,
      isActive: userRoles.isActive,
      role: roles
    }).from(userRoles).innerJoin(roles, eq(userRoles.roleId, roles.id)).where(and(
      eq(userRoles.userId, userId),
      eq(userRoles.isActive, true)
    ));
  }
  async assignRoleToUser(userId, roleId, assignedBy) {
    const [newUserRole] = await db2.insert(userRoles).values({
      userId,
      roleId,
      assignedBy,
      isActive: true
    }).returning();
    return newUserRole;
  }
  async revokeRoleFromUser(userId, roleId) {
    const result = await db2.update(userRoles).set({ isActive: false }).where(and(
      eq(userRoles.userId, userId),
      eq(userRoles.roleId, roleId)
    ));
    return (result.rowCount || 0) > 0;
  }
  async getUserPermissions(userId) {
    return await db2.select({
      id: permissions.id,
      name: permissions.name,
      displayName: permissions.displayName,
      description: permissions.description,
      category: permissions.category,
      resource: permissions.resource,
      action: permissions.action,
      isSystem: permissions.isSystem,
      createdAt: permissions.createdAt
    }).from(permissions).innerJoin(rolePermissions, eq(permissions.id, rolePermissions.permissionId)).innerJoin(userRoles, eq(rolePermissions.roleId, userRoles.roleId)).where(and(
      eq(userRoles.userId, userId),
      eq(userRoles.isActive, true)
    ));
  }
  // Role Permission operations
  async getRolePermissions(roleId) {
    return await db2.select({
      id: permissions.id,
      name: permissions.name,
      displayName: permissions.displayName,
      description: permissions.description,
      category: permissions.category,
      resource: permissions.resource,
      action: permissions.action,
      isSystem: permissions.isSystem,
      createdAt: permissions.createdAt
    }).from(permissions).innerJoin(rolePermissions, eq(permissions.id, rolePermissions.permissionId)).where(eq(rolePermissions.roleId, roleId));
  }
  async assignPermissionToRole(roleId, permissionId) {
    const [newRolePermission] = await db2.insert(rolePermissions).values({
      roleId,
      permissionId
    }).returning();
    return newRolePermission;
  }
  async assignPermissionsToRole(roleName, permissionNames) {
    const role = await this.getRoleByName(roleName);
    if (!role) {
      throw new Error(`Role ${roleName} not found`);
    }
    for (const permissionName of permissionNames) {
      const permission = await this.getPermissionByName(permissionName);
      if (permission) {
        const existingRolePermissions = await db2.select().from(rolePermissions).where(and(
          eq(rolePermissions.roleId, role.id),
          eq(rolePermissions.permissionId, permission.id)
        ));
        if (existingRolePermissions.length === 0) {
          await this.assignPermissionToRole(role.id, permission.id);
        }
      }
    }
  }
  async revokePermissionFromRole(roleId, permissionId) {
    const result = await db2.delete(rolePermissions).where(and(
      eq(rolePermissions.roleId, roleId),
      eq(rolePermissions.permissionId, permissionId)
    ));
    return (result.rowCount || 0) > 0;
  }
  // Audit Log operations
  async createAuditLog(auditData) {
    const [newAuditLog] = await db2.insert(auditLog).values(auditData).returning();
    return newAuditLog;
  }
  async getAuditLogs(userId, limit = 100) {
    if (userId) {
      return await db2.select().from(auditLog).where(eq(auditLog.userId, userId)).orderBy(desc(auditLog.timestamp)).limit(limit);
    }
    return await db2.select().from(auditLog).orderBy(desc(auditLog.timestamp)).limit(limit);
  }
  // Admin Dashboard operations
  async getAllUsersWithRoles() {
    const allUsers = await db2.select().from(users2);
    const usersWithRoles = await Promise.all(
      allUsers.map(async (user) => {
        const userRoles2 = await this.getUserRoles(user.id);
        return {
          ...user,
          userRoles: userRoles2
        };
      })
    );
    return usersWithRoles;
  }
  async getSystemStats() {
    const [totalUsersResult] = await db2.select({ count: sql3`count(*)` }).from(users2);
    const [totalRolesResult] = await db2.select({ count: sql3`count(*)` }).from(roles);
    const [totalPermissionsResult] = await db2.select({ count: sql3`count(*)` }).from(permissions);
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3);
    const [recentLoginsResult] = await db2.select({ count: sql3`count(*)` }).from(auditLog).where(and(
      eq(auditLog.action, "user_login"),
      sql3`${auditLog.timestamp} > ${thirtyDaysAgo}`
    ));
    const [activeUsersResult] = await db2.select({ count: sql3`count(distinct ${auditLog.userId})` }).from(auditLog).where(sql3`${auditLog.timestamp} > ${thirtyDaysAgo}`);
    return {
      totalUsers: totalUsersResult.count,
      activeUsers: activeUsersResult.count || 0,
      totalRoles: totalRolesResult.count,
      totalPermissions: totalPermissionsResult.count,
      recentLogins: recentLoginsResult.count || 0
    };
  }
  async getRecentActivity(limit = 50) {
    return await db2.select().from(auditLog).orderBy(desc(auditLog.timestamp)).limit(limit);
  }
  async getUserStats(userId) {
    const [loginCountResult] = await db2.select({ count: sql3`count(*)` }).from(auditLog).where(and(
      eq(auditLog.userId, userId),
      eq(auditLog.action, "user_login")
    ));
    const [lastLoginResult] = await db2.select({ timestamp: auditLog.timestamp }).from(auditLog).where(and(
      eq(auditLog.userId, userId),
      eq(auditLog.action, "user_login")
    )).orderBy(desc(auditLog.timestamp)).limit(1);
    const [actionsCountResult] = await db2.select({ count: sql3`count(*)` }).from(auditLog).where(eq(auditLog.userId, userId));
    return {
      loginCount: loginCountResult.count || 0,
      lastLogin: lastLoginResult?.timestamp || void 0,
      sessionDuration: void 0,
      // Could be calculated if we track session end times
      actionsCount: actionsCountResult.count || 0
    };
  }
  async getPermissionMatrix() {
    const allRoles = await this.getRoles();
    const matrix = await Promise.all(
      allRoles.map(async (role) => {
        const permissions2 = await this.getRolePermissions(role.id);
        return {
          roleId: role.id,
          roleName: role.name,
          permissions: permissions2
        };
      })
    );
    return matrix;
  }
  async searchUsers(query, limit = 50) {
    const lowerQuery = `%${query.toLowerCase()}%`;
    return await db2.select().from(users2).where(sql3`
        lower(${users2.username}) like ${lowerQuery} OR 
        lower(${users2.email}) like ${lowerQuery} OR
        lower(${users2.firstName}) like ${lowerQuery} OR
        lower(${users2.lastName}) like ${lowerQuery}
      `).limit(limit);
  }
  async getUsersByRole(roleId) {
    return await db2.select({
      id: users2.id,
      username: users2.username,
      email: users2.email,
      password: users2.password,
      role: users2.role,
      authProvider: users2.authProvider,
      oauthId: users2.oauthId,
      profileImage: users2.profileImage,
      firstName: users2.firstName,
      lastName: users2.lastName,
      createdAt: users2.createdAt
    }).from(users2).innerJoin(userRoles, eq(users2.id, userRoles.userId)).where(and(
      eq(userRoles.roleId, roleId),
      eq(userRoles.isActive, true)
    ));
  }
};
var storage = new DatabaseStorage();

// server/services/erpService.ts
var ERP_SYSTEMS = {
  sap: {
    name: "sap",
    displayName: "SAP S/4HANA",
    description: "AI-driven analytics, in-memory computing",
    oauthConfig: {
      authUrl: "https://api.sap.com/oauth/authorize",
      tokenUrl: "https://api.sap.com/oauth/token",
      clientId: process.env.SAP_CLIENT_ID || "",
      scopes: ["read", "write", "analytics"]
    },
    apiBaseUrl: "https://api.sap.com/v1"
  },
  netsuite: {
    name: "netsuite",
    displayName: "Oracle NetSuite",
    description: "Cloud-native, financial management",
    oauthConfig: {
      authUrl: "https://system.netsuite.com/app/login/oauth2/authorize.nl",
      tokenUrl: "https://system.netsuite.com/app/login/oauth2/token.nl",
      clientId: process.env.NETSUITE_CLIENT_ID || "",
      scopes: ["restlets", "rest_webservices"]
    },
    apiBaseUrl: "https://system.netsuite.com/app/site/hosting/restlet.nl"
  },
  dynamics365: {
    name: "dynamics365",
    displayName: "Microsoft Dynamics 365",
    description: "Office 365 integration, Copilot AI",
    oauthConfig: {
      authUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
      tokenUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/token",
      clientId: process.env.DYNAMICS_CLIENT_ID || "",
      scopes: ["https://service.powerapps.com/user_impersonation"]
    },
    apiBaseUrl: "https://api.businesscentral.dynamics.com/v2.0"
  },
  oracle_fusion: {
    name: "oracle_fusion",
    displayName: "Oracle Fusion Cloud",
    description: "Large enterprise focus, robust functionality",
    oauthConfig: {
      authUrl: "https://idcs-oracle.identity.oraclecloud.com/oauth2/v1/authorize",
      tokenUrl: "https://idcs-oracle.identity.oraclecloud.com/oauth2/v1/token",
      clientId: process.env.ORACLE_FUSION_CLIENT_ID || "",
      scopes: ["urn:opc:idm:__myscopes__"]
    },
    apiBaseUrl: "https://api.oraclecloud.com/20160918"
  },
  workday: {
    name: "workday",
    displayName: "Workday ERP",
    description: "HR-centric, cloud-first design",
    oauthConfig: {
      authUrl: "https://impl-cc.workday.com/ccx/oauth2/authorize",
      tokenUrl: "https://impl-cc.workday.com/ccx/oauth2/token",
      clientId: process.env.WORKDAY_CLIENT_ID || "",
      scopes: ["openid", "profile"]
    },
    apiBaseUrl: "https://wd2-impl-services1.workday.com"
  },
  ifs: {
    name: "ifs",
    displayName: "IFS Cloud",
    description: "Asset management, field service",
    oauthConfig: {
      authUrl: "https://oauth.ifs.com/authorize",
      tokenUrl: "https://oauth.ifs.com/token",
      clientId: process.env.IFS_CLIENT_ID || "",
      scopes: ["read", "write"]
    },
    apiBaseUrl: "https://api.ifs.com/v1"
  },
  epicor: {
    name: "epicor",
    displayName: "Epicor Kinetic",
    description: "Manufacturing focus, modern interface",
    oauthConfig: {
      authUrl: "https://api.epicor.com/oauth/authorize",
      tokenUrl: "https://api.epicor.com/oauth/token",
      clientId: process.env.EPICOR_CLIENT_ID || "",
      scopes: ["erp.read", "erp.write"]
    },
    apiBaseUrl: "https://api.epicor.com/v1"
  },
  infor: {
    name: "infor",
    displayName: "Infor LN/M3",
    description: "Industry-specific solutions",
    oauthConfig: {
      authUrl: "https://mingle-ionapi.inforcloudsuite.com/INFOR_GRID/as/authorization.oauth2",
      tokenUrl: "https://mingle-ionapi.inforcloudsuite.com/INFOR_GRID/as/token.oauth2",
      clientId: process.env.INFOR_CLIENT_ID || "",
      scopes: ["read", "write"]
    },
    apiBaseUrl: "https://mingle-ionapi.inforcloudsuite.com"
  },
  acumatica: {
    name: "acumatica",
    displayName: "Acumatica Cloud",
    description: "Modular pricing, construction/distribution",
    oauthConfig: {
      authUrl: "https://api.acumatica.com/oauth/authorize",
      tokenUrl: "https://api.acumatica.com/oauth/token",
      clientId: process.env.ACUMATICA_CLIENT_ID || "",
      scopes: ["api"]
    },
    apiBaseUrl: "https://api.acumatica.com/entity"
  },
  sage: {
    name: "sage",
    displayName: "Sage Intacct",
    description: "Financial management, accounting-first",
    oauthConfig: {
      authUrl: "https://api.intacct.com/ia/acct/oauth2/authorize",
      tokenUrl: "https://api.intacct.com/ia/acct/oauth2/token",
      clientId: process.env.SAGE_CLIENT_ID || "",
      scopes: ["read", "write"]
    },
    apiBaseUrl: "https://api.intacct.com"
  }
};
var ERPService = class {
  async getConnectedSystems(userId) {
    const connections = await storage.getErpConnections(userId);
    return Object.values(ERP_SYSTEMS).map((system) => ({
      ...system,
      isConnected: connections.some((conn) => conn.erpSystem === system.name && conn.isConnected),
      lastSync: connections.find((conn) => conn.erpSystem === system.name)?.lastSync || void 0
    }));
  }
  async initiateOAuthFlow(erpSystem, userId, redirectUri) {
    const system = ERP_SYSTEMS[erpSystem];
    if (!system) {
      throw new Error(`ERP system ${erpSystem} not supported`);
    }
    const existingConnection = await storage.getErpConnection(userId, erpSystem);
    if (!existingConnection) {
      await storage.createErpConnection({
        userId,
        erpSystem,
        isConnected: false,
        config: system.oauthConfig
      });
    }
    const params = new URLSearchParams({
      client_id: system.oauthConfig.clientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: system.oauthConfig.scopes.join(" "),
      state: `${userId}-${erpSystem}-${Date.now()}`
    });
    return `${system.oauthConfig.authUrl}?${params.toString()}`;
  }
  async handleOAuthCallback(code, state) {
    const [userId, erpSystem] = state.split("-");
    const system = ERP_SYSTEMS[erpSystem];
    if (!system) {
      throw new Error(`Invalid ERP system: ${erpSystem}`);
    }
    const tokenResponse = await fetch(system.oauthConfig.tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: system.oauthConfig.clientId,
        client_secret: process.env[`${erpSystem.toUpperCase()}_CLIENT_SECRET`] || "",
        code,
        redirect_uri: process.env.OAUTH_REDIRECT_URI || ""
      })
    });
    if (!tokenResponse.ok) {
      throw new Error(`Failed to exchange code for tokens: ${tokenResponse.statusText}`);
    }
    const tokens = await tokenResponse.json();
    const connection = await storage.getErpConnection(userId, erpSystem);
    if (!connection) {
      throw new Error("Connection not found");
    }
    const updatedConnection = await storage.updateErpConnection(connection.id, {
      isConnected: true,
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      tokenExpiry: new Date(Date.now() + tokens.expires_in * 1e3),
      lastSync: /* @__PURE__ */ new Date()
    });
    if (!updatedConnection) {
      throw new Error("Failed to update connection");
    }
    return updatedConnection;
  }
  async fetchERPData(userId, erpSystem, endpoint) {
    const connection = await storage.getErpConnection(userId, erpSystem);
    if (!connection || !connection.isConnected || !connection.accessToken) {
      throw new Error(`${erpSystem} not connected`);
    }
    const system = ERP_SYSTEMS[erpSystem];
    const response = await fetch(`${system.apiBaseUrl}${endpoint}`, {
      headers: {
        "Authorization": `Bearer ${connection.accessToken}`,
        "Content-Type": "application/json"
      }
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch data from ${erpSystem}: ${response.statusText}`);
    }
    await storage.updateErpConnection(connection.id, {
      lastSync: /* @__PURE__ */ new Date()
    });
    return await response.json();
  }
  async aggregateERPData(userId) {
    const connections = await storage.getErpConnections(userId);
    const connectedSystems = connections.filter((conn) => conn.isConnected);
    const aggregatedData = {};
    if (connectedSystems.length > 0) {
      for (const connection of connectedSystems) {
        try {
          const data = await this.fetchERPData(userId, connection.erpSystem, "/summary");
          aggregatedData[connection.erpSystem] = data;
        } catch (error) {
          console.error(`Failed to fetch data from ${connection.erpSystem}:`, error);
          aggregatedData[connection.erpSystem] = { error: error.message };
        }
      }
    } else {
      aggregatedData.demo = this.getDemoERPData();
    }
    return aggregatedData;
  }
  getDemoERPData() {
    return {
      company: {
        name: "TechCorp Industries",
        size: "Large Enterprise",
        revenue: "$200M annually",
        employees: 2800,
        industry: "Technology Manufacturing"
      },
      financial: {
        monthlyRevenue: {
          current: 167e5,
          // $16.7M
          change: 12.5,
          currency: "USD",
          period: "Current Month"
        },
        quarterlyRevenue: {
          q1: 482e5,
          q2: 521e5,
          q3: 498e5,
          q4_projected: 55e6,
          currency: "USD"
        },
        profitMargin: {
          current: 18.3,
          target: 20,
          trend: "improving"
        },
        expenses: {
          operational: 1365e4,
          salaries: 89e5,
          marketing: 21e5,
          rnd: 42e5
        }
      },
      operations: {
        activeOrders: {
          count: 2847,
          change: 8.2,
          totalValue: 124e5,
          avgOrderValue: 4354
        },
        inventory: {
          fillRate: 94.2,
          change: -2.1,
          totalItems: 15680,
          lowStockItems: 234,
          overstockItems: 89
        },
        production: {
          efficiency: 91.3,
          change: 6.4,
          unitsProduced: 45670,
          defectRate: 0.8,
          onTimeDelivery: 96.5
        }
      },
      systems: {
        performance: {
          uptime: 98.8,
          change: 15.7,
          avgResponseTime: 245,
          errorRate: 0.03
        },
        integrations: [
          {
            system: "SAP S/4HANA",
            status: "active",
            lastSync: new Date(Date.now() - 2 * 60 * 1e3),
            dataPoints: 15680
          },
          {
            system: "Oracle NetSuite",
            status: "active",
            lastSync: new Date(Date.now() - 5 * 60 * 1e3),
            dataPoints: 8934
          },
          {
            system: "Microsoft Dynamics 365",
            status: "active",
            lastSync: new Date(Date.now() - 8 * 60 * 1e3),
            dataPoints: 12456
          }
        ]
      },
      trends: {
        salesGrowth: "12.5% month-over-month increase",
        inventoryOptimization: "Slight decrease in fill rate, investigate supply chain",
        systemPerformance: "Significant improvement in uptime and response times",
        operationalEfficiency: "Strong gains in production efficiency"
      }
    };
  }
  async disconnectSystem(userId, erpSystem) {
    const connection = await storage.getErpConnection(userId, erpSystem);
    if (!connection) {
      throw new Error(`${erpSystem} connection not found`);
    }
    await storage.updateErpConnection(connection.id, {
      isConnected: false,
      accessToken: null,
      refreshToken: null,
      tokenExpiry: null,
      lastSync: null
    });
  }
};
var erpService = new ERPService();

// server/services/outlookClient.ts
import { Client } from "@microsoft/microsoft-graph-client";
var connectionSettings = null;
async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  const hostname = process.env.CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY ? "repl " + process.env.REPL_IDENTITY : process.env.WEB_REPL_RENEWAL ? "depl " + process.env.WEB_REPL_RENEWAL : null;
  if (!xReplitToken) {
    throw new Error("X_REPLIT_TOKEN not found for repl/depl");
  }
  connectionSettings = await fetch(
    "https://" + hostname + "/api/v2/connection?include_secrets=true&connector_names=outlook",
    {
      headers: {
        "Accept": "application/json",
        "X_REPLIT_TOKEN": xReplitToken
      }
    }
  ).then((res) => res.json()).then((data) => data.items?.[0]);
  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;
  if (!connectionSettings || !accessToken) {
    throw new Error("Outlook not connected");
  }
  return accessToken;
}
async function getUncachableOutlookClient() {
  const accessToken = await getAccessToken();
  return Client.initWithMiddleware({
    authProvider: {
      getAccessToken: async () => accessToken
    }
  });
}

// server/services/emailService.ts
import crypto from "crypto";

// server/env-validation.ts
var REQUIRED_ENV_VARS = [
  {
    name: "JWT_SECRET",
    description: "Secret key for signing JWT tokens",
    example: "openssl rand -base64 64"
  },
  {
    name: "TOKEN_ENCRYPTION_KEY",
    description: "32-byte encryption key for securing OAuth tokens and sensitive data",
    example: "openssl rand -hex 32"
  }
];
var OPTIONAL_ENV_VARS = [
  {
    name: "GOOGLE_CLIENT_ID",
    description: "Google OAuth client ID",
    impact: "Google OAuth login will be unavailable"
  },
  {
    name: "GOOGLE_CLIENT_SECRET",
    description: "Google OAuth client secret",
    impact: "Google OAuth login will be unavailable"
  },
  {
    name: "MICROSOFT_CLIENT_ID",
    description: "Microsoft OAuth client ID",
    impact: "Microsoft OAuth login will be unavailable"
  },
  {
    name: "MICROSOFT_CLIENT_SECRET",
    description: "Microsoft OAuth client secret",
    impact: "Microsoft OAuth login will be unavailable"
  }
];
function validateEnvironment() {
  const errors = [];
  const warnings = [];
  for (const envVar of REQUIRED_ENV_VARS) {
    const value = process.env[envVar.name];
    if (!value || value.trim() === "") {
      errors.push(`Missing required environment variable: ${envVar.name}`);
      errors.push(`  Description: ${envVar.description}`);
      if (envVar.example) {
        errors.push(`  Example: ${envVar.example}`);
      }
    }
  }
  for (const envVar of OPTIONAL_ENV_VARS) {
    const value = process.env[envVar.name];
    if (!value || value.trim() === "") {
      warnings.push(`Optional environment variable not set: ${envVar.name}`);
      warnings.push(`  Impact: ${envVar.impact}`);
    }
  }
  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}
function enforceEnvironmentValidation() {
  const result = validateEnvironment();
  if (!result.isValid) {
    console.error("\n\u274C CRITICAL: Application startup failed due to missing required environment variables:\n");
    result.errors.forEach((error) => console.error(`  ${error}`));
    console.error("\nApplication cannot start without these variables. Please set them and restart.\n");
    process.exit(1);
  }
  if (result.warnings.length > 0) {
    console.warn("\n\u26A0\uFE0F  WARNING: Some optional environment variables are not set:\n");
    result.warnings.forEach((warning) => console.warn(`  ${warning}`));
    console.warn("\n");
  }
}
function getJwtSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET environment variable is not set. This should have been caught during startup validation.");
  }
  return secret;
}
function getTokenEncryptionKey() {
  const key = process.env.TOKEN_ENCRYPTION_KEY;
  if (!key) {
    throw new Error("TOKEN_ENCRYPTION_KEY environment variable is not set. This should have been caught during startup validation.");
  }
  return key;
}

// server/services/emailService.ts
var EMAIL_PROVIDERS = {
  gmail: {
    name: "gmail",
    displayName: "Gmail",
    oauthConfig: {
      authUrl: "https://accounts.google.com/o/oauth2/v2/auth",
      tokenUrl: "https://oauth2.googleapis.com/token",
      clientId: process.env.GOOGLE_CLIENT_ID || process.env.GMAIL_CLIENT_ID || "",
      scopes: ["https://www.googleapis.com/auth/gmail.send", "https://www.googleapis.com/auth/gmail.readonly"]
    },
    sendEndpoint: "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
  },
  outlook: {
    name: "outlook",
    displayName: "Outlook.com",
    oauthConfig: {
      authUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
      tokenUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/token",
      clientId: process.env.MICROSOFT_CLIENT_ID || "",
      scopes: ["https://graph.microsoft.com/Mail.Send", "https://graph.microsoft.com/Mail.Read"]
    },
    sendEndpoint: "https://graph.microsoft.com/v1.0/me/sendMail"
  }
};
var EMAIL_TEMPLATES = {
  weekly_report: {
    name: "Weekly Report",
    subject: "ERP Dashboard Report - Week {{week}}",
    body: `Dear {{recipient}},

Please find attached your weekly ERP dashboard report containing:

{{#kpis}}
- {{name}}: {{value}} ({{change}})
{{/kpis}}

Key Insights:
{{#insights}}
- {{.}}
{{/insights}}

Best regards,
ERP Connect Pro`,
    variables: ["week", "recipient", "kpis", "insights"]
  },
  kpi_alert: {
    name: "KPI Alert",
    subject: "Alert: {{kpi_name}} Threshold Exceeded",
    body: `Alert: {{kpi_name}} has exceeded the configured threshold.

Current Value: {{current_value}}
Threshold: {{threshold}}
Change: {{change}}

Please review and take appropriate action.

ERP Connect Pro`,
    variables: ["kpi_name", "current_value", "threshold", "change"]
  },
  system_status: {
    name: "System Status Update",
    subject: "ERP System Status Update",
    body: `System Status Update:

{{#systems}}
- {{name}}: {{status}} (Last sync: {{last_sync}})
{{/systems}}

{{#if issues}}
Issues requiring attention:
{{#issues}}
- {{.}}
{{/issues}}
{{/if}}

ERP Connect Pro`,
    variables: ["systems", "issues"]
  }
};
var EmailService = class {
  // Secure encryption key from environment - validated at startup
  encryptionKey = getTokenEncryptionKey();
  async getEmailConfigurations(userId) {
    return await storage.getEmailConfigurations(userId);
  }
  // Security helper methods for OAuth
  generateSecureState() {
    return crypto.randomBytes(32).toString("hex");
  }
  generateCodeVerifier() {
    return crypto.randomBytes(32).toString("base64url");
  }
  async generateCodeChallenge(verifier) {
    const hash = crypto.createHash("sha256").update(verifier).digest();
    return hash.toString("base64url");
  }
  async encryptToken(token) {
    try {
      const algorithm = "aes-256-gcm";
      const iv = crypto.randomBytes(12);
      const key = crypto.createHash("sha256").update(this.encryptionKey).digest();
      const cipher = crypto.createCipheriv(algorithm, key, iv);
      let encrypted = cipher.update(token, "utf8", "base64");
      encrypted += cipher.final("base64");
      const authTag = cipher.getAuthTag();
      return `${iv.toString("base64")}:${encrypted}:${authTag.toString("base64")}`;
    } catch (error) {
      console.error("Token encryption error:", error);
      throw new Error("Failed to encrypt token");
    }
  }
  async decryptToken(encryptedToken) {
    try {
      const parts = encryptedToken.split(":");
      if (parts.length !== 3) {
        throw new Error("Invalid encrypted token format - expected iv:ciphertext:authTag");
      }
      const [ivBase64, encrypted, authTagBase64] = parts;
      const iv = Buffer.from(ivBase64, "base64");
      const authTag = Buffer.from(authTagBase64, "base64");
      const key = crypto.createHash("sha256").update(this.encryptionKey).digest();
      const algorithm = "aes-256-gcm";
      const decipher = crypto.createDecipheriv(algorithm, key, iv);
      decipher.setAuthTag(authTag);
      let decrypted = decipher.update(encrypted, "base64", "utf8");
      decrypted += decipher.final("utf8");
      return decrypted;
    } catch (error) {
      console.error("Token decryption error:", error);
      throw new Error("Failed to decrypt token - authentication failed or data corrupted");
    }
  }
  // Email OAuth session management
  async createEmailOAuthSession(provider, state, userId) {
    const expiresAt = new Date(Date.now() + 10 * 60 * 1e3);
    await storage.createOAuthSession({
      state,
      provider: `email_${provider}`,
      // Prefix to distinguish from user auth
      isCompleted: false,
      expiresAt,
      authResult: JSON.stringify({ userId })
    });
  }
  async getEmailOAuthSessionByState(state) {
    const session = await storage.getOAuthSessionByState(state);
    if (!session || !session.provider.startsWith("email_")) {
      return null;
    }
    const authResult = session.authResult ? JSON.parse(session.authResult) : {};
    return {
      id: session.id,
      provider: session.provider.replace("email_", ""),
      userId: authResult.userId,
      isCompleted: session.isCompleted,
      expiresAt: session.expiresAt,
      authResult
    };
  }
  async updateEmailOAuthSession(state, updates) {
    const session = await storage.getOAuthSessionByState(state);
    if (!session) {
      throw new Error("OAuth session not found");
    }
    const currentResult = session.authResult ? JSON.parse(session.authResult) : {};
    await storage.updateOAuthSession(session.id, {
      authResult: JSON.stringify({ ...currentResult, ...updates })
    });
  }
  async completeEmailOAuthSession(state) {
    const session = await storage.getOAuthSessionByState(state);
    if (session) {
      await storage.updateOAuthSession(session.id, { isCompleted: true });
    }
  }
  async checkOutlookConnection() {
    try {
      const client = await getUncachableOutlookClient();
      const user = await client.api("/me").get();
      return {
        isConnected: true,
        email: user.mail || user.userPrincipalName
      };
    } catch (error) {
      console.error("Outlook connection check failed:", error);
      return { isConnected: false };
    }
  }
  async initiateEmailOAuth(provider, userId, redirectUri) {
    const emailProvider = EMAIL_PROVIDERS[provider];
    if (!emailProvider) {
      throw new Error(`Email provider ${provider} not supported`);
    }
    const allowedRedirectUris = [
      process.env.EMAIL_OAUTH_REDIRECT_URI,
      `${process.env.FRONTEND_URL || "http://localhost:5000"}/api/email/callback`,
      "http://localhost:5000/api/email/callback"
    ].filter(Boolean);
    if (!allowedRedirectUris.includes(redirectUri)) {
      throw new Error("Invalid redirect URI");
    }
    const existingConfig = await storage.getEmailConfigurations(userId);
    const existing = existingConfig.find((config) => config.provider === provider);
    if (!existing) {
      await storage.createEmailConfiguration({
        userId,
        provider,
        email: "",
        // Will be updated after OAuth
        isActive: false
      });
    }
    const state = this.generateSecureState();
    await this.createEmailOAuthSession(provider, state, userId);
    const codeVerifier = this.generateCodeVerifier();
    const codeChallenge = await this.generateCodeChallenge(codeVerifier);
    await this.updateEmailOAuthSession(state, { codeVerifier });
    const params = new URLSearchParams({
      client_id: emailProvider.oauthConfig.clientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: emailProvider.oauthConfig.scopes.join(" "),
      state,
      code_challenge: codeChallenge,
      code_challenge_method: "S256"
    });
    return `${emailProvider.oauthConfig.authUrl}?${params.toString()}`;
  }
  async handleEmailOAuthCallback(code, state) {
    const session = await this.getEmailOAuthSessionByState(state);
    if (!session || session.isCompleted || /* @__PURE__ */ new Date() > session.expiresAt) {
      throw new Error("Invalid or expired OAuth session");
    }
    const provider = session.provider;
    const userId = session.userId;
    const codeVerifier = session.authResult?.codeVerifier;
    const emailProvider = EMAIL_PROVIDERS[provider];
    if (!emailProvider) {
      throw new Error(`Invalid email provider: ${provider}`);
    }
    const tokenParams = {
      grant_type: "authorization_code",
      client_id: emailProvider.oauthConfig.clientId,
      code,
      redirect_uri: process.env.EMAIL_OAUTH_REDIRECT_URI || "",
      code_verifier: codeVerifier
    };
    if (!codeVerifier) {
      tokenParams.client_secret = process.env[`${provider.toUpperCase()}_CLIENT_SECRET`] || process.env.GOOGLE_CLIENT_SECRET || "";
    }
    const tokenResponse = await fetch(emailProvider.oauthConfig.tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams(tokenParams)
    });
    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text();
      throw new Error(`Failed to exchange code for tokens: ${tokenResponse.statusText} - ${errorText}`);
    }
    const tokens = await tokenResponse.json();
    let userEmail = "";
    if (provider === "gmail") {
      const profileResponse = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/profile", {
        headers: { "Authorization": `Bearer ${tokens.access_token}` }
      });
      if (profileResponse.ok) {
        const profile = await profileResponse.json();
        userEmail = profile.emailAddress;
      }
    } else if (provider === "outlook") {
      const profileResponse = await fetch("https://graph.microsoft.com/v1.0/me", {
        headers: { "Authorization": `Bearer ${tokens.access_token}` }
      });
      if (profileResponse.ok) {
        const profile = await profileResponse.json();
        userEmail = profile.mail || profile.userPrincipalName;
      }
    }
    const encryptedAccessToken = await this.encryptToken(tokens.access_token);
    const encryptedRefreshToken = tokens.refresh_token ? await this.encryptToken(tokens.refresh_token) : null;
    const configurations = await storage.getEmailConfigurations(userId);
    const config = configurations.find((c) => c.provider === provider);
    if (!config) {
      throw new Error("Email configuration not found");
    }
    const updatedConfig = await storage.updateEmailConfiguration(config.id, {
      email: userEmail,
      accessToken: encryptedAccessToken,
      refreshToken: encryptedRefreshToken,
      tokenExpiry: new Date(Date.now() + tokens.expires_in * 1e3),
      isActive: true
    });
    if (!updatedConfig) {
      throw new Error("Failed to update email configuration");
    }
    await this.completeEmailOAuthSession(state);
    return updatedConfig;
  }
  async sendEmail(userId, provider, message, templateName, templateVars) {
    try {
      let finalMessage = message;
      if (templateName && EMAIL_TEMPLATES[templateName] && templateVars) {
        const template = EMAIL_TEMPLATES[templateName];
        const rendered = this.renderTemplate(template, templateVars);
        finalMessage = {
          ...message,
          subject: rendered.subject,
          body: rendered.body
        };
      }
      if (provider === "gmail") {
        const configurations = await storage.getEmailConfigurations(userId);
        const config = configurations.find((c) => c.provider === provider && c.isActive);
        if (!config || !config.accessToken) {
          throw new Error(`Gmail not configured or not active`);
        }
        if (config.tokenExpiry && config.tokenExpiry < /* @__PURE__ */ new Date()) {
          if (!config.refreshToken) {
            throw new Error("Gmail access token expired and no refresh token available");
          }
          await this.refreshAccessToken(userId, provider, config.id);
          const updatedConfigs = await storage.getEmailConfigurations(userId);
          const updatedConfig = updatedConfigs.find((c) => c.id === config.id);
          if (!updatedConfig?.accessToken) {
            throw new Error("Failed to refresh Gmail access token");
          }
          config.accessToken = updatedConfig.accessToken;
        }
        const decryptedToken = await this.decryptToken(config.accessToken);
        return await this.sendGmailMessage(decryptedToken, finalMessage);
      } else if (provider === "outlook") {
        return await this.sendOutlookMessage("", finalMessage);
      } else if (provider === "smtp") {
        const configurations = await storage.getEmailConfigurations(userId);
        const config = configurations.find((c) => c.provider === provider && c.isActive);
        if (!config) {
          throw new Error(`SMTP not configured`);
        }
        return await this.sendSMTPMessage(config, finalMessage);
      }
      throw new Error(`Unsupported provider: ${provider}`);
    } catch (error) {
      console.error(`Failed to send email via ${provider}:`, error);
      throw error;
    }
  }
  async sendSMTPMessage(config, message) {
    try {
      const smtpConfig = JSON.parse(config.accessToken || "{}");
      if (!smtpConfig.host || !smtpConfig.auth) {
        throw new Error("Invalid SMTP configuration");
      }
      const decryptedPassword = await this.decryptToken(smtpConfig.auth.pass);
      const emailContent = this.buildRFC2822Message(message);
      return await this.sendViaSMTP({
        ...smtpConfig,
        auth: {
          ...smtpConfig.auth,
          pass: decryptedPassword
        }
      }, emailContent);
    } catch (error) {
      console.error("Failed to send SMTP email:", error);
      return false;
    }
  }
  async sendGmailMessage(accessToken, message) {
    const email = this.buildRFC2822Message(message);
    const base64Email = Buffer.from(email).toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
    const response = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ raw: base64Email })
    });
    return response.ok;
  }
  async sendOutlookMessage(accessToken, message) {
    try {
      const client = await getUncachableOutlookClient();
      const outlookMessage = {
        subject: message.subject,
        body: {
          contentType: message.isHtml ? "HTML" : "Text",
          content: message.body
        },
        toRecipients: message.to.map((email) => ({ emailAddress: { address: email } })),
        ccRecipients: message.cc?.map((email) => ({ emailAddress: { address: email } })) || [],
        bccRecipients: message.bcc?.map((email) => ({ emailAddress: { address: email } })) || []
      };
      await client.api("/me/sendMail").post({
        message: outlookMessage
      });
      return true;
    } catch (error) {
      console.error("Failed to send Outlook email:", error);
      return false;
    }
  }
  buildRFC2822Message(message) {
    const lines = [
      `To: ${message.to.join(", ")}`,
      `Subject: ${message.subject}`,
      `Content-Type: ${message.isHtml ? "text/html" : "text/plain"}; charset=utf-8`,
      "",
      message.body
    ];
    if (message.cc && message.cc.length > 0) {
      lines.splice(1, 0, `Cc: ${message.cc.join(", ")}`);
    }
    if (message.bcc && message.bcc.length > 0) {
      lines.splice(1, 0, `Bcc: ${message.bcc.join(", ")}`);
    }
    return lines.join("\r\n");
  }
  getEmailTemplates() {
    return EMAIL_TEMPLATES;
  }
  renderTemplate(template, variables) {
    let subject = template.subject;
    let body = template.body;
    const allowedVariables = template.variables || [];
    Object.keys(variables).forEach((key) => {
      if (!allowedVariables.includes(key)) {
        console.warn(`Template variable '${key}' not in allowed list for template`);
        return;
      }
      let sanitizedValue = String(variables[key]).replace(/[<>&"']/g, (match) => {
        const escapeMap = {
          "<": "&lt;",
          ">": "&gt;",
          "&": "&amp;",
          '"': "&quot;",
          "'": "&#x27;"
        };
        return escapeMap[match] || match;
      });
      const regex = new RegExp(`{{${key}}}`, "g");
      subject = subject.replace(regex, sanitizedValue);
      body = body.replace(regex, sanitizedValue);
    });
    return { subject, body };
  }
  // Token refresh implementation
  async refreshAccessToken(userId, provider, configId) {
    const configurations = await storage.getEmailConfigurations(userId);
    const config = configurations.find((c) => c.id === configId);
    if (!config || !config.refreshToken) {
      throw new Error("No refresh token available");
    }
    const emailProvider = EMAIL_PROVIDERS[provider];
    if (!emailProvider) {
      throw new Error(`Email provider ${provider} not supported`);
    }
    try {
      const decryptedRefreshToken = await this.decryptToken(config.refreshToken);
      const tokenResponse = await fetch(emailProvider.oauthConfig.tokenUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          client_id: emailProvider.oauthConfig.clientId,
          client_secret: process.env[`${provider.toUpperCase()}_CLIENT_SECRET`] || process.env.GOOGLE_CLIENT_SECRET || "",
          refresh_token: decryptedRefreshToken
        })
      });
      if (!tokenResponse.ok) {
        throw new Error(`Token refresh failed: ${tokenResponse.statusText}`);
      }
      const tokens = await tokenResponse.json();
      const encryptedAccessToken = await this.encryptToken(tokens.access_token);
      const encryptedRefreshToken = tokens.refresh_token ? await this.encryptToken(tokens.refresh_token) : config.refreshToken;
      await storage.updateEmailConfiguration(configId, {
        accessToken: encryptedAccessToken,
        refreshToken: encryptedRefreshToken,
        tokenExpiry: new Date(Date.now() + tokens.expires_in * 1e3)
      });
    } catch (error) {
      console.error("Token refresh error:", error);
      throw new Error("Failed to refresh access token");
    }
  }
  // SMTP implementation using Node.js net module
  async sendViaSMTP(config, emailContent) {
    return new Promise((resolve, reject) => {
      const net = __require("net");
      const tls = __require("tls");
      const client = config.secure ? tls.connect(config.port, config.host) : net.createConnection(config.port, config.host);
      let step = 0;
      const commands = [
        `HELO ${config.host}`,
        "AUTH LOGIN",
        Buffer.from(config.auth.user).toString("base64"),
        Buffer.from(config.auth.pass).toString("base64"),
        `MAIL FROM: <${config.auth.user}>`,
        emailContent.match(/^To: (.+)$/m)?.[1]?.split(",").map((to) => `RCPT TO: <${to.trim()}>`),
        "DATA",
        emailContent,
        ".",
        "QUIT"
      ].flat().filter(Boolean);
      client.on("data", (data) => {
        const response = data.toString();
        console.log("SMTP Response:", response);
        if (response.startsWith("2") || response.startsWith("3")) {
          if (step < commands.length) {
            client.write(commands[step] + "\r\n");
            step++;
          } else {
            client.end();
            resolve(true);
          }
        } else {
          client.end();
          reject(new Error(`SMTP Error: ${response}`));
        }
      });
      client.on("connect", () => {
        console.log("Connected to SMTP server");
      });
      client.on("error", (err) => {
        reject(err);
      });
      client.on("end", () => {
        resolve(step >= commands.length);
      });
    });
  }
};
var emailService = new EmailService();

// server/services/openai.ts
import OpenAI from "openai";
function getOpenAIClient() {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY environment variable is required");
  }
  return new OpenAI({ apiKey });
}
async function analyzeERPData(request) {
  try {
    const systemPrompt = `You are Jeldi's expert AI business analyst with deep knowledge of enterprise systems like SAP S/4HANA, Oracle NetSuite, Microsoft Dynamics 365, and other major ERP platforms. 

Your role is to:
1. Analyze ERP data and provide actionable business insights
2. Answer questions about financial performance, operations, inventory, and system efficiency
3. Identify trends and anomalies in the data
4. Provide strategic recommendations based on the data
5. Suggest data visualizations when appropriate
6. Generate follow-up questions to deepen analysis

You have access to real-time ERP data including:
- Financial metrics (revenue, expenses, profit margins, cash flow)
- Operational data (orders, inventory, performance, supply chain)
- System metrics (uptime, sync status, data quality)
- Historical trends and comparisons
- Customer and vendor analytics

Always respond with structured JSON containing your analysis, insights, recommendations, chart suggestions, and follow-up questions. Be specific, actionable, and business-focused.`;
    let contextSection = "";
    if (request.conversationHistory && request.conversationHistory.length > 0) {
      contextSection = `

Previous Conversation Context:
${request.conversationHistory.map(
        (item, index) => `${index + 1}. Q: ${item.query}
A: ${item.response}`
      ).join("\n\n")}`;
    }
    if (request.context) {
      contextSection += `

Additional Context: ${request.context}`;
    }
    const userPrompt = `User Query: ${request.query}
${contextSection}

Available ERP Data:
${JSON.stringify(request.erpData, null, 2)}

Please analyze this data and provide:
1. A direct answer to the user's question
2. Key insights from the data (3-5 specific insights)
3. Actionable recommendations (2-4 concrete actions)
4. List of data sources used in your analysis
5. Chart/visualization suggestions if data warrants it
6. 2-3 follow-up questions to deepen the analysis

Respond in JSON format with the structure: 
{
  "response": "string (direct answer)",
  "insights": ["string"],
  "recommendations": ["string"],
  "dataUsed": ["string"],
  "chartSuggestions": [{"type": "bar|line|pie|table", "title": "string", "description": "string"}],
  "followUpQuestions": ["string"]
}`;
    const openai = getOpenAIClient();
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 1500
    });
    if (!response.choices || response.choices.length === 0) {
      throw new Error("OpenAI returned no response choices");
    }
    const responseContent = response.choices[0].message.content;
    if (!responseContent) {
      throw new Error("OpenAI returned empty content");
    }
    let result;
    try {
      result = JSON.parse(responseContent);
    } catch (parseError) {
      throw new Error("Failed to parse OpenAI response as JSON: " + responseContent);
    }
    return {
      response: result.response || "Unable to analyze the data at this time.",
      insights: result.insights || [],
      recommendations: result.recommendations || [],
      dataUsed: result.dataUsed || [],
      chartSuggestions: result.chartSuggestions || [],
      followUpQuestions: result.followUpQuestions || []
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to analyze ERP data: " + error.message);
  }
}
async function generateKPIInsights(kpiData2) {
  try {
    const openai = getOpenAIClient();
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a KPI analyst. Analyze the provided KPI data and generate insights about performance trends, alerts for concerning metrics, and overall business health. Respond in JSON format."
        },
        {
          role: "user",
          content: `Analyze these KPI metrics and provide insights:
          
          ${JSON.stringify(kpiData2, null, 2)}
          
          Respond with JSON: { "summary": "string", "alerts": ["string"], "trends": ["string"] }`
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 500
    });
    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      summary: result.summary || "KPI analysis unavailable",
      alerts: result.alerts || [],
      trends: result.trends || []
    };
  } catch (error) {
    console.error("KPI analysis error:", error);
    return {
      summary: "Unable to analyze KPI data",
      alerts: [],
      trends: []
    };
  }
}

// server/routes.ts
import bcrypt from "bcryptjs";
import jwt2 from "jsonwebtoken";
import passport2 from "passport";

// server/services/oauthService.ts
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as MicrosoftStrategy } from "passport-microsoft";
import jwt from "jsonwebtoken";
import crypto2 from "crypto";
var getJwtSecretAtRuntime = () => getJwtSecret();
var OAUTH_PROVIDERS = {
  google: {
    name: "google",
    displayName: "Google",
    clientId: process.env.GOOGLE_CLIENT_ID || "",
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
    callbackURL: process.env.GOOGLE_CALLBACK_URL || "/api/auth/google/callback",
    scope: ["profile", "email"]
  },
  microsoft: {
    name: "microsoft",
    displayName: "Microsoft",
    clientId: process.env.MICROSOFT_CLIENT_ID || "",
    clientSecret: process.env.MICROSOFT_CLIENT_SECRET || "",
    callbackURL: process.env.MICROSOFT_CALLBACK_URL || "/api/auth/microsoft/callback",
    scope: ["openid", "profile", "email", "offline_access", "User.Read"]
  }
};
var OAuthService = class _OAuthService {
  static generateSecureState() {
    return crypto2.randomBytes(32).toString("hex");
  }
  static async createOAuthSession(provider, state) {
    const expiresAt = new Date(Date.now() + 10 * 60 * 1e3);
    await storage.createOAuthSession({
      state,
      provider,
      isCompleted: false,
      expiresAt,
      authResult: null
    });
  }
  static async validateAndCompleteOAuthSession(state, authResult) {
    const session = await storage.getOAuthSessionByState(state);
    if (!session || session.isCompleted || /* @__PURE__ */ new Date() > session.expiresAt) {
      return false;
    }
    await storage.updateOAuthSession(session.id, {
      isCompleted: true,
      authResult
    });
    return true;
  }
  static async getCompletedOAuthSession(sessionId) {
    const session = await storage.getOAuthSession(sessionId);
    if (!session || !session.isCompleted) {
      return null;
    }
    await storage.deleteOAuthSession(session.id);
    return session.authResult;
  }
  static setupStrategies() {
    if (OAUTH_PROVIDERS.google.clientId && OAUTH_PROVIDERS.google.clientSecret) {
      passport.use(new GoogleStrategy(
        {
          clientID: OAUTH_PROVIDERS.google.clientId,
          clientSecret: OAUTH_PROVIDERS.google.clientSecret,
          callbackURL: OAUTH_PROVIDERS.google.callbackURL,
          passReqToCallback: true
        },
        async (req, accessToken, refreshToken, profile, done) => {
          try {
            const state = req.query?.state;
            if (!state) {
              return done(new Error("Missing CSRF state parameter"), null);
            }
            const result = await _OAuthService.handleOAuthCallback("google", profile, accessToken, refreshToken, state);
            return done(null, result);
          } catch (error) {
            return done(error, null);
          }
        }
      ));
    }
    if (OAUTH_PROVIDERS.microsoft.clientId && OAUTH_PROVIDERS.microsoft.clientSecret) {
      passport.use(new MicrosoftStrategy(
        {
          clientID: OAUTH_PROVIDERS.microsoft.clientId,
          clientSecret: OAUTH_PROVIDERS.microsoft.clientSecret,
          callbackURL: OAUTH_PROVIDERS.microsoft.callbackURL,
          scope: OAUTH_PROVIDERS.microsoft.scope,
          passReqToCallback: true
        },
        async (req, accessToken, refreshToken, profile, done) => {
          try {
            const state = req.query?.state;
            if (!state) {
              return done(new Error("Missing CSRF state parameter"), null);
            }
            const result = await _OAuthService.handleOAuthCallback("microsoft", profile, accessToken, refreshToken, state);
            return done(null, result);
          } catch (error) {
            return done(error, null);
          }
        }
      ));
    }
    passport.serializeUser((user, done) => {
      done(null, user);
    });
    passport.deserializeUser((user, done) => {
      done(null, user);
    });
  }
  static async handleOAuthCallback(provider, profile, accessToken, refreshToken, state) {
    let email = "";
    let firstName = "";
    let lastName = "";
    let profileImage = "";
    let oauthId = "";
    if (provider === "google") {
      email = profile.emails?.[0]?.value || "";
      firstName = profile.name?.givenName || "";
      lastName = profile.name?.familyName || "";
      profileImage = profile.photos?.[0]?.value || "";
      oauthId = profile.id;
    } else if (provider === "microsoft") {
      email = profile.emails?.[0]?.value || profile.username || "";
      firstName = profile.name?.givenName || "";
      lastName = profile.name?.familyName || "";
      profileImage = profile.photos?.[0]?.value || "";
      oauthId = profile.id;
    }
    if (!email || !oauthId) {
      throw new Error("Invalid OAuth profile data");
    }
    let user = await storage.getUserByEmail(email);
    if (!user) {
      user = await storage.getUserByOAuthId(provider, oauthId);
    }
    if (user) {
      if (user.authProvider === "local" || user.oauthId !== oauthId) {
        user = await storage.updateUser(user.id, {
          authProvider: provider,
          oauthId,
          profileImage: profileImage || user.profileImage,
          firstName: firstName || user.firstName,
          lastName: lastName || user.lastName
        });
      }
    } else {
      const userData = {
        username: email.split("@")[0] + "_" + Date.now(),
        // Generate unique username
        email,
        authProvider: provider,
        oauthId,
        profileImage,
        firstName,
        lastName,
        role: "user"
      };
      user = await storage.createOAuthUser(userData);
    }
    if (!user) {
      throw new Error("Failed to create or update user");
    }
    const token = jwt.sign({ userId: user.id }, getJwtSecretAtRuntime(), { expiresIn: "7d" });
    const authResult = {
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
        profileImage: user.profileImage
      }
    };
    const sessionValid = await _OAuthService.validateAndCompleteOAuthSession(state, authResult);
    if (!sessionValid) {
      throw new Error("Invalid or expired OAuth session");
    }
    return { sessionState: state, authResult };
  }
  static getAvailableProviders() {
    return Object.values(OAUTH_PROVIDERS).filter(
      (provider) => provider.clientId && provider.clientSecret
    );
  }
  static isProviderConfigured(provider) {
    const config = OAUTH_PROVIDERS[provider];
    return !!(config && config.clientId && config.clientSecret);
  }
};

// server/services/rbac.ts
var RBACService = class {
  /**
   * Get user with their roles and permissions
   */
  static async getUserWithPermissions(userId) {
    try {
      const user = await storage.getUser(userId);
      if (!user) return null;
      const userRoles2 = await storage.getUserRoles(userId);
      const permissions2 = await storage.getUserPermissions(userId);
      return {
        ...user,
        userRoles: userRoles2,
        permissions: permissions2
      };
    } catch (error) {
      console.error("Error getting user with permissions:", error);
      return null;
    }
  }
  /**
   * Check if user has specific permission
   */
  static async hasPermission(userId, resource, action) {
    try {
      const permissions2 = await storage.getUserPermissions(userId);
      return permissions2.some((p) => p.resource === resource && p.action === action);
    } catch (error) {
      console.error("Error checking permission:", error);
      return false;
    }
  }
  /**
   * Check if user has any of the specified roles
   */
  static async hasAnyRole(userId, roleNames) {
    try {
      const userRoles2 = await storage.getUserRoles(userId);
      const userRoleNames = userRoles2.map((ur) => ur.role.name);
      return roleNames.some((roleName) => userRoleNames.includes(roleName));
    } catch (error) {
      console.error("Error checking roles:", error);
      return false;
    }
  }
  /**
   * Check if user has all of the specified roles
   */
  static async hasAllRoles(userId, roleNames) {
    try {
      const userRoles2 = await storage.getUserRoles(userId);
      const userRoleNames = userRoles2.map((ur) => ur.role.name);
      return roleNames.every((roleName) => userRoleNames.includes(roleName));
    } catch (error) {
      console.error("Error checking roles:", error);
      return false;
    }
  }
  /**
   * Get permissions for a specific resource
   */
  static async getResourcePermissions(userId, resource) {
    try {
      const permissions2 = await storage.getUserPermissions(userId);
      return permissions2.filter((p) => p.resource === resource);
    } catch (error) {
      console.error("Error getting resource permissions:", error);
      return [];
    }
  }
  /**
   * Log audit event
   */
  static async logAuditEvent(auditData) {
    try {
      await storage.createAuditLog(auditData);
    } catch (error) {
      console.error("Error logging audit event:", error);
    }
  }
  /**
   * Initialize default roles and permissions
   */
  static async initializeDefaultRoles() {
    try {
      const defaultRoles = [
        {
          name: "admin",
          displayName: "Administrator",
          description: "Full system access and user management",
          color: "#dc2626",
          isSystem: true,
          isActive: true
        },
        {
          name: "ops_manager",
          displayName: "Operations Manager",
          description: "Operations and workflow management",
          color: "#2563eb",
          isSystem: true,
          isActive: true
        },
        {
          name: "finance",
          displayName: "Finance",
          description: "Financial data and reporting access",
          color: "#059669",
          isSystem: true,
          isActive: true
        },
        {
          name: "cfo",
          displayName: "CFO",
          description: "Executive financial oversight and analytics",
          color: "#7c3aed",
          isSystem: true,
          isActive: true
        },
        {
          name: "project_manager",
          displayName: "Project Manager",
          description: "Project tracking and resource management",
          color: "#ea580c",
          isSystem: true,
          isActive: true
        },
        {
          name: "cost_manager",
          displayName: "Cost Manager",
          description: "Cost analysis and budget oversight",
          color: "#0891b2",
          isSystem: true,
          isActive: true
        },
        {
          name: "sales",
          displayName: "Sales",
          description: "Sales analytics and customer data",
          color: "#dc2626",
          isSystem: true,
          isActive: true
        },
        {
          name: "marketing",
          displayName: "Marketing",
          description: "Marketing metrics and campaign analysis",
          color: "#c2410c",
          isSystem: true,
          isActive: true
        },
        {
          name: "user",
          displayName: "User",
          description: "Basic user access",
          color: "#6366f1",
          isSystem: true,
          isActive: true
        }
      ];
      const defaultPermissions = [
        // User Management
        { name: "user.create", displayName: "Create Users", description: "Create new user accounts", category: "user_management", resource: "users", action: "create", isSystem: true },
        { name: "user.read", displayName: "View Users", description: "View user information", category: "user_management", resource: "users", action: "read", isSystem: true },
        { name: "user.update", displayName: "Update Users", description: "Update user information", category: "user_management", resource: "users", action: "update", isSystem: true },
        { name: "user.delete", displayName: "Delete Users", description: "Delete user accounts", category: "user_management", resource: "users", action: "delete", isSystem: true },
        { name: "user.manage_roles", displayName: "Manage User Roles", description: "Assign and revoke user roles", category: "user_management", resource: "users", action: "manage_roles", isSystem: true },
        // Financial Data
        { name: "financial.view", displayName: "View Financial Data", description: "Access financial reports and analytics", category: "financial_data", resource: "financial", action: "read", isSystem: true },
        { name: "financial.create", displayName: "Create Financial Records", description: "Create financial data entries", category: "financial_data", resource: "financial", action: "create", isSystem: true },
        { name: "financial.update", displayName: "Update Financial Data", description: "Modify financial records", category: "financial_data", resource: "financial", action: "update", isSystem: true },
        { name: "financial.export", displayName: "Export Financial Data", description: "Export financial reports", category: "financial_data", resource: "financial", action: "export", isSystem: true },
        // ERP Access
        { name: "erp.view", displayName: "View ERP Data", description: "Access ERP system data", category: "erp_access", resource: "erp_connections", action: "read", isSystem: true },
        { name: "erp.connect", displayName: "Connect ERP Systems", description: "Connect new ERP systems", category: "erp_access", resource: "erp_connections", action: "create", isSystem: true },
        { name: "erp.manage", displayName: "Manage ERP Connections", description: "Manage ERP system connections", category: "erp_access", resource: "erp_connections", action: "manage", isSystem: true },
        { name: "erp.sync", displayName: "Sync ERP Data", description: "Synchronize ERP data", category: "erp_access", resource: "erp_connections", action: "sync", isSystem: true },
        // KPI & Dashboard
        { name: "kpi.view", displayName: "View KPIs", description: "View KPI data and dashboards", category: "dashboard", resource: "kpis", action: "read", isSystem: true },
        { name: "kpi.create", displayName: "Create KPIs", description: "Create new KPI configurations", category: "dashboard", resource: "kpis", action: "create", isSystem: true },
        { name: "kpi.update", displayName: "Update KPIs", description: "Modify KPI configurations", category: "dashboard", resource: "kpis", action: "update", isSystem: true },
        { name: "kpi.delete", displayName: "Delete KPIs", description: "Remove KPI configurations", category: "dashboard", resource: "kpis", action: "delete", isSystem: true },
        // AI Assistant
        { name: "ai.basic", displayName: "Basic AI Access", description: "Basic AI assistant functionality", category: "ai_assistant", resource: "ai", action: "basic", isSystem: true },
        { name: "ai.advanced", displayName: "Advanced AI Features", description: "Advanced AI assistant features", category: "ai_assistant", resource: "ai", action: "advanced", isSystem: true },
        { name: "ai.admin", displayName: "AI Administration", description: "AI system administration", category: "ai_assistant", resource: "ai", action: "admin", isSystem: true },
        // Email
        { name: "email.send", displayName: "Send Emails", description: "Send emails through the system", category: "email", resource: "email", action: "send", isSystem: true },
        { name: "email.manage", displayName: "Manage Email Settings", description: "Manage email configurations", category: "email", resource: "email", action: "manage", isSystem: true },
        // Settings
        { name: "settings.view", displayName: "View Settings", description: "View system settings", category: "settings", resource: "settings", action: "read", isSystem: true },
        { name: "settings.update", displayName: "Update Settings", description: "Modify system settings", category: "settings", resource: "settings", action: "update", isSystem: true },
        { name: "settings.admin", displayName: "Admin Settings", description: "Administrative settings access", category: "settings", resource: "settings", action: "admin", isSystem: true }
      ];
      for (const role of defaultRoles) {
        await storage.createRoleIfNotExists(role);
      }
      for (const permission of defaultPermissions) {
        await storage.createPermissionIfNotExists(permission);
      }
      const rolePermissionMappings = {
        admin: [
          "user.create",
          "user.read",
          "user.update",
          "user.delete",
          "user.manage_roles",
          "financial.view",
          "financial.create",
          "financial.update",
          "financial.export",
          "erp.view",
          "erp.connect",
          "erp.manage",
          "erp.sync",
          "kpi.view",
          "kpi.create",
          "kpi.update",
          "kpi.delete",
          "ai.basic",
          "ai.advanced",
          "ai.admin",
          "email.send",
          "email.manage",
          "settings.view",
          "settings.update",
          "settings.admin"
        ],
        ops_manager: [
          "erp.view",
          "erp.connect",
          "erp.manage",
          "erp.sync",
          "kpi.view",
          "kpi.create",
          "kpi.update",
          "ai.basic",
          "ai.advanced",
          "email.send",
          "settings.view"
        ],
        finance: [
          "financial.view",
          "financial.create",
          "financial.update",
          "financial.export",
          "kpi.view",
          "ai.basic",
          "email.send",
          "settings.view"
        ],
        cfo: [
          "financial.view",
          "financial.export",
          "kpi.view",
          "ai.basic",
          "ai.advanced",
          "email.send",
          "settings.view"
        ],
        project_manager: [
          "kpi.view",
          "kpi.create",
          "kpi.update",
          "ai.basic",
          "email.send",
          "settings.view"
        ],
        cost_manager: [
          "financial.view",
          "financial.export",
          "kpi.view",
          "ai.basic",
          "email.send",
          "settings.view"
        ],
        sales: [
          "kpi.view",
          "ai.basic",
          "email.send",
          "settings.view"
        ],
        marketing: [
          "kpi.view",
          "ai.basic",
          "email.send",
          "settings.view"
        ],
        user: [
          "kpi.view",
          "ai.basic",
          "settings.view"
        ]
      };
      for (const [roleName, permissionNames] of Object.entries(rolePermissionMappings)) {
        await storage.assignPermissionsToRole(roleName, permissionNames);
      }
      console.log("Default roles and permissions initialized successfully");
    } catch (error) {
      console.error("Error initializing default roles:", error);
    }
  }
};
var loadUserPermissions = async (req, res, next) => {
  if (req.user) {
    try {
      const userWithPermissions = await RBACService.getUserWithPermissions(req.user.id);
      if (userWithPermissions) {
        req.userPermissions = userWithPermissions.permissions;
        req.userRoles = userWithPermissions.userRoles.map((ur) => ur.role);
      }
    } catch (error) {
      console.error("Error loading user permissions:", error);
    }
  }
  next();
};
var requirePermission = (resource, action) => {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    const hasPermission = await RBACService.hasPermission(req.user.id, resource, action);
    if (!hasPermission) {
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "permission_denied",
        resource,
        resourceId: null,
        oldValue: null,
        newValue: { requiredPermission: `${resource}.${action}` },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      return res.status(403).json({
        message: "Insufficient permissions",
        required: `${resource}.${action}`
      });
    }
    next();
  };
};
var requireAdmin = async (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  const hasAdminRole = await RBACService.hasAnyRole(req.user.id, ["admin"]);
  if (!hasAdminRole && req.user.role !== "admin") {
    await RBACService.logAuditEvent({
      userId: req.user.id,
      action: "admin_access_denied",
      resource: "admin_access",
      resourceId: null,
      oldValue: null,
      newValue: {
        hasRBACAdminRole: hasAdminRole,
        legacyRole: req.user.role,
        fallbackUsed: false
      },
      ipAddress: req.ip,
      userAgent: req.get("User-Agent") || null
    });
    return res.status(403).json({
      message: "Admin access required",
      details: "Contact system administrator for proper role assignment"
    });
  }
  await RBACService.logAuditEvent({
    userId: req.user.id,
    action: "admin_access_granted",
    resource: "admin_access",
    resourceId: null,
    oldValue: null,
    newValue: {
      hasRBACAdminRole: hasAdminRole,
      legacyRole: req.user.role,
      fallbackUsed: !hasAdminRole && req.user.role === "admin"
    },
    ipAddress: req.ip,
    userAgent: req.get("User-Agent") || null
  });
  next();
};

// server/routes.ts
var getJwtSecretAtRuntime2 = () => getJwtSecret();
var wsClients = /* @__PURE__ */ new Map();
async function broadcastERPStatusUpdate(userId) {
  const wsClient = wsClients.get(userId);
  if (wsClient && wsClient.ws.readyState === WebSocket.OPEN) {
    if (!wsClient.permissions.includes("erp_connections.read")) {
      return;
    }
    try {
      const systems = await erpService.getConnectedSystems(userId);
      wsClient.ws.send(JSON.stringify({
        type: "erp_status_update",
        data: systems.map((system) => ({
          name: system.name,
          displayName: system.displayName,
          description: system.description,
          isConnected: system.isConnected,
          lastSync: system.lastSync,
          status: system.isConnected ? "active" : "inactive"
        }))
      }));
    } catch (error) {
      console.error("Error broadcasting ERP status update:", error);
    }
  }
}
async function registerRoutes(app2, options = {}) {
  OAuthService.setupStrategies();
  app2.use(passport2.initialize());
  try {
    await RBACService.initializeDefaultRoles();
    console.log("RBAC system initialized successfully");
  } catch (error) {
    console.error("Failed to initialize RBAC system:", error);
  }
  setInterval(async () => {
    try {
      await storage.cleanupExpiredOAuthSessions();
    } catch (error) {
      console.error("OAuth session cleanup error:", error);
    }
  }, 5 * 60 * 1e3);
  const authenticateToken = async (req, res, next) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (!token) {
      return res.status(401).json({ message: "Access token required" });
    }
    try {
      const decoded = jwt2.verify(token, getJwtSecretAtRuntime2());
      const user = await storage.getUser(decoded.userId);
      if (!user) {
        return res.status(403).json({ message: "Invalid token" });
      }
      req.user = user;
      next();
    } catch (error) {
      return res.status(403).json({ message: "Invalid token" });
    }
  };
  app2.post("/api/auth/register", async (req, res) => {
    try {
      const { username, email, password } = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
      if (!password) {
        return res.status(400).json({ message: "Password is required for registration" });
      }
      const hashedPassword = await bcrypt.hash(password, 10);
      const userCount = await storage.getUserCount();
      const isFirstUser = userCount === 0;
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        authProvider: "local",
        role: isFirstUser ? "admin" : "user"
      });
      const token = jwt2.sign({ userId: user.id }, getJwtSecretAtRuntime2(), { expiresIn: "7d" });
      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, role: user.role }
      });
    } catch (error) {
      res.status(400).json({ message: "Registration failed", error: error.message });
    }
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      if (user.authProvider !== "local" || !user.password) {
        return res.status(401).json({ message: "Please use OAuth login for this account" });
      }
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const token = jwt2.sign({ userId: user.id }, getJwtSecretAtRuntime2(), { expiresIn: "7d" });
      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, role: user.role }
      });
    } catch (error) {
      res.status(400).json({ message: "Login failed", error: error.message });
    }
  });
  app2.post("/api/auth/logout", authenticateToken, async (req, res) => {
    try {
      res.json({
        message: "Logout successful",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({
        message: "Logout failed",
        error: error.message
      });
    }
  });
  app2.get("/api/auth/me", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        authProvider: user.authProvider
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user info", error: error.message });
    }
  });
  app2.get("/api/oauth/providers", async (req, res) => {
    try {
      const providers = OAuthService.getAvailableProviders();
      res.json(providers.map((p) => ({
        name: p.name,
        displayName: p.displayName
      })));
    } catch (error) {
      res.status(500).json({ message: "Failed to get OAuth providers", error: error.message });
    }
  });
  app2.get("/api/auth/oauth-result/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const authResult = await OAuthService.getCompletedOAuthSession(sessionId);
      if (!authResult) {
        return res.status(404).json({ message: "OAuth session not found or expired" });
      }
      res.json(authResult);
    } catch (error) {
      console.error("OAuth session retrieval error:", error);
      res.status(500).json({ message: "Failed to retrieve OAuth result", error: error.message });
    }
  });
  app2.get("/api/auth/google", async (req, res, next) => {
    try {
      if (!OAuthService.isProviderConfigured("google")) {
        return res.status(503).json({
          message: "Google OAuth is not configured",
          error: "service_unavailable",
          details: {
            description: "Google OAuth authentication is not available because the required environment variables are not set.",
            required_variables: ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
            instructions: "Please contact your administrator to configure Google OAuth credentials."
          }
        });
      }
      const state = OAuthService.generateSecureState();
      await OAuthService.createOAuthSession("google", state);
      passport2.authenticate("google", {
        scope: ["profile", "email"],
        state
      })(req, res, next);
    } catch (error) {
      console.error("Google OAuth initiation error:", error);
      res.redirect("/login?error=oauth_failed");
    }
  });
  app2.get(
    "/api/auth/google/callback",
    passport2.authenticate("google", { session: false, failureRedirect: "/login?error=oauth_failed" }),
    async (req, res) => {
      try {
        const result = req.user;
        res.redirect(`/login?oauth_session=${result.sessionState}`);
      } catch (error) {
        console.error("Google OAuth callback error:", error);
        res.redirect("/login?error=oauth_failed");
      }
    }
  );
  app2.get("/api/user/preferences", authenticateToken, async (req, res) => {
    try {
      let preferences = await storage.getUserPreferences(req.user.id);
      if (!preferences) {
        preferences = await storage.createUserPreferences({ userId: req.user.id });
      }
      res.json(preferences);
    } catch (error) {
      console.error("Get user preferences error:", error);
      res.status(500).json({ message: "Failed to get user preferences", error: error.message });
    }
  });
  app2.put("/api/user/preferences", authenticateToken, async (req, res) => {
    try {
      const updates = updateUserPreferencesSchema.parse(req.body);
      let preferences = await storage.getUserPreferences(req.user.id);
      if (!preferences) {
        preferences = await storage.createUserPreferences({ userId: req.user.id });
      }
      const updatedPreferences = await storage.updateUserPreferences(req.user.id, updates);
      if (!updatedPreferences) {
        return res.status(404).json({ message: "User preferences not found" });
      }
      res.json(updatedPreferences);
    } catch (error) {
      console.error("Update user preferences error:", error);
      res.status(400).json({ message: "Failed to update user preferences", error: error.message });
    }
  });
  app2.put("/api/user/profile", authenticateToken, async (req, res) => {
    try {
      const { username, email, firstName, lastName, profileImage } = req.body;
      if (!username && !email && !firstName && !lastName && !profileImage) {
        return res.status(400).json({ message: "At least one field must be provided for update" });
      }
      if (email && email !== req.user.email) {
        const existingUser = await storage.getUserByEmail(email);
        if (existingUser && existingUser.id !== req.user.id) {
          return res.status(400).json({ message: "Email already in use" });
        }
      }
      if (username && username !== req.user.username) {
        const existingUser = await storage.getUserByUsername(username);
        if (existingUser && existingUser.id !== req.user.id) {
          return res.status(400).json({ message: "Username already in use" });
        }
      }
      const updates = {};
      if (username) updates.username = username;
      if (email) updates.email = email;
      if (firstName) updates.firstName = firstName;
      if (lastName) updates.lastName = lastName;
      if (profileImage) updates.profileImage = profileImage;
      const updatedUser = await storage.updateUser(req.user.id, updates);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Update user profile error:", error);
      res.status(400).json({ message: "Failed to update user profile", error: error.message });
    }
  });
  app2.put("/api/user/password", authenticateToken, async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Both current and new password are required" });
      }
      if (newPassword.length < 8) {
        return res.status(400).json({ message: "New password must be at least 8 characters long" });
      }
      if (req.user.authProvider !== "local" || !req.user.password) {
        return res.status(400).json({ message: "Password change not available for OAuth accounts" });
      }
      const isValidCurrentPassword = await bcrypt.compare(currentPassword, req.user.password);
      if (!isValidCurrentPassword) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }
      const hashedNewPassword = await bcrypt.hash(newPassword, 10);
      const updatedUser = await storage.updateUser(req.user.id, { password: hashedNewPassword });
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ message: "Password updated successfully" });
    } catch (error) {
      console.error("Change password error:", error);
      res.status(400).json({ message: "Failed to change password", error: error.message });
    }
  });
  app2.post("/api/user/preferences/reset", authenticateToken, async (req, res) => {
    try {
      const preferences = await storage.resetUserPreferences(req.user.id);
      res.json(preferences);
    } catch (error) {
      console.error("Reset user preferences error:", error);
      res.status(500).json({ message: "Failed to reset user preferences", error: error.message });
    }
  });
  app2.get("/api/auth/microsoft", async (req, res, next) => {
    try {
      if (!OAuthService.isProviderConfigured("microsoft")) {
        return res.status(503).json({
          message: "Microsoft OAuth is not configured",
          error: "service_unavailable",
          details: {
            description: "Microsoft OAuth authentication is not available because the required environment variables are not set.",
            required_variables: ["MICROSOFT_CLIENT_ID", "MICROSOFT_CLIENT_SECRET"],
            instructions: "Please contact your administrator to configure Microsoft OAuth credentials."
          }
        });
      }
      const state = OAuthService.generateSecureState();
      await OAuthService.createOAuthSession("microsoft", state);
      passport2.authenticate("microsoft", {
        scope: ["openid", "profile", "email", "offline_access", "User.Read"],
        state
      })(req, res, next);
    } catch (error) {
      console.error("Microsoft OAuth initiation error:", error);
      res.redirect("/login?error=oauth_failed");
    }
  });
  app2.get(
    "/api/auth/microsoft/callback",
    passport2.authenticate("microsoft", { session: false, failureRedirect: "/login?error=oauth_failed" }),
    async (req, res) => {
      try {
        const result = req.user;
        res.redirect(`/login?oauth_session=${result.sessionState}`);
      } catch (error) {
        console.error("Microsoft OAuth callback error:", error);
        res.redirect("/login?error=oauth_failed");
      }
    }
  );
  app2.get("/api/erp/systems", authenticateToken, requirePermission("erp_connections", "read"), async (req, res) => {
    try {
      const systems = await erpService.getConnectedSystems(req.user.id);
      res.json(systems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ERP systems", error: error.message });
    }
  });
  app2.post("/api/erp/connect/:system", authenticateToken, requirePermission("erp_connections", "create"), async (req, res) => {
    try {
      const { system } = req.params;
      const redirectUri = process.env.OAUTH_REDIRECT_URI || `${req.protocol}://${req.get("host")}/api/erp/callback`;
      const authUrl = await erpService.initiateOAuthFlow(system, req.user.id, redirectUri);
      res.json({ authUrl });
    } catch (error) {
      res.status(400).json({ message: "Failed to initiate OAuth", error: error.message });
    }
  });
  app2.get("/api/erp/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      if (!code || !state) {
        return res.status(400).json({ message: "Missing code or state parameter" });
      }
      const connection = await erpService.handleOAuthCallback(code, state);
      await broadcastERPStatusUpdate(connection.userId);
      res.redirect(`${process.env.FRONTEND_URL || "http://localhost:5000"}/dashboard?connected=${connection.erpSystem}`);
    } catch (error) {
      res.status(400).json({ message: "OAuth callback failed", error: error.message });
    }
  });
  app2.delete("/api/erp/disconnect/:system", authenticateToken, requirePermission("erp_connections", "manage"), async (req, res) => {
    try {
      const { system } = req.params;
      await erpService.disconnectSystem(req.user.id, system);
      await broadcastERPStatusUpdate(req.user.id);
      res.json({ message: "System disconnected successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to disconnect system", error: error.message });
    }
  });
  app2.get("/api/erp/data", authenticateToken, requirePermission("erp_connections", "read"), async (req, res) => {
    try {
      const data = await erpService.aggregateERPData(req.user.id);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ERP data", error: error.message });
    }
  });
  app2.get("/api/rbac/me", authenticateToken, loadUserPermissions, async (req, res) => {
    try {
      const userWithRoles = await RBACService.getUserWithPermissions(req.user.id);
      if (!userWithRoles) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({
        user: req.user,
        roles: userWithRoles.userRoles.map((ur) => ur.role),
        permissions: userWithRoles.permissions,
        roleNames: userWithRoles.userRoles.map((ur) => ur.role.name)
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user roles", error: error.message });
    }
  });
  app2.get("/api/rbac/roles", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const roles2 = await storage.getRoles();
      res.json(roles2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch roles", error: error.message });
    }
  });
  app2.get("/api/rbac/permissions", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const permissions2 = await storage.getPermissions();
      const permissionsByCategory = permissions2.reduce((acc, permission) => {
        if (!acc[permission.category]) {
          acc[permission.category] = [];
        }
        acc[permission.category].push(permission);
        return acc;
      }, {});
      res.json({
        permissions: permissions2,
        byCategory: permissionsByCategory,
        categories: Object.keys(permissionsByCategory)
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch permissions", error: error.message });
    }
  });
  app2.get("/api/rbac/users", authenticateToken, requireAdmin, async (req, res) => {
    try {
      if (typeof storage.getAllUsersWithRoles === "function") {
        const users3 = await storage.getAllUsersWithRoles();
        res.json(users3);
      } else {
        res.json({
          message: "User management endpoint implemented with basic functionality",
          note: "For production use, implement getAllUsersWithRoles in storage layer",
          adminAccess: true,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "users_list_accessed",
        resource: "user_management",
        resourceId: null,
        oldValue: null,
        newValue: { accessedBy: req.user.id },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users", error: error.message });
    }
  });
  app2.post("/api/rbac/assign-role", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { userId, roleId } = roleAssignmentSchema.parse(req.body);
      const userRole = await storage.assignRoleToUser(userId, roleId, req.user.id);
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "role_assigned",
        resource: "users",
        resourceId: userId,
        oldValue: null,
        newValue: { roleId, assignedBy: req.user.id },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json({ message: "Role assigned successfully", userRole });
    } catch (error) {
      res.status(400).json({ message: "Failed to assign role", error: error.message });
    }
  });
  app2.delete("/api/rbac/revoke-role", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { userId, roleId } = roleRevocationSchema.parse(req.body);
      const success = await storage.revokeRoleFromUser(userId, roleId);
      if (success) {
        await RBACService.logAuditEvent({
          userId: req.user.id,
          action: "role_revoked",
          resource: "users",
          resourceId: userId,
          oldValue: { roleId },
          newValue: null,
          ipAddress: req.ip,
          userAgent: req.get("User-Agent") || null
        });
        res.json({ message: "Role revoked successfully" });
      } else {
        res.status(404).json({ message: "Role assignment not found" });
      }
    } catch (error) {
      res.status(400).json({ message: "Failed to revoke role", error: error.message });
    }
  });
  app2.post("/api/rbac/check-permission", authenticateToken, async (req, res) => {
    try {
      const { resource, action } = req.body;
      const hasPermission = await RBACService.hasPermission(req.user.id, resource, action);
      res.json({
        hasPermission,
        permission: `${resource}.${action}`,
        userId: req.user.id
      });
    } catch (error) {
      res.status(400).json({ message: "Failed to check permission", error: error.message });
    }
  });
  app2.get("/api/rbac/audit-logs", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { userId, limit } = req.query;
      const auditLogs = await storage.getAuditLogs(
        userId,
        limit ? parseInt(limit) : 100
      );
      res.json(auditLogs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch audit logs", error: error.message });
    }
  });
  app2.post("/api/rbac/roles", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const roleData = insertRoleSchema.parse(req.body);
      const newRole = await storage.createRole(roleData);
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "role_created",
        resource: "roles",
        resourceId: newRole.id,
        oldValue: null,
        newValue: roleData,
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.status(201).json(newRole);
    } catch (error) {
      res.status(400).json({ message: "Failed to create role", error: error.message });
    }
  });
  app2.put("/api/rbac/roles/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = updateRoleSchema.parse(req.body);
      const existingRole = await storage.getRole(id);
      const updatedRole = await storage.updateRole(id, updates);
      if (updatedRole) {
        await RBACService.logAuditEvent({
          userId: req.user.id,
          action: "role_updated",
          resource: "roles",
          resourceId: id,
          oldValue: existingRole,
          newValue: updates,
          ipAddress: req.ip,
          userAgent: req.get("User-Agent") || null
        });
        res.json(updatedRole);
      } else {
        res.status(404).json({ message: "Role not found" });
      }
    } catch (error) {
      res.status(400).json({ message: "Failed to update role", error: error.message });
    }
  });
  app2.get("/api/admin/dashboard/stats", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const [systemStats, recentActivity] = await Promise.all([
        storage.getSystemStats(),
        storage.getRecentActivity(10)
      ]);
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "admin_dashboard_accessed",
        resource: "admin_dashboard",
        resourceId: null,
        oldValue: null,
        newValue: { timestamp: (/* @__PURE__ */ new Date()).toISOString() },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json({
        stats: systemStats,
        recentActivity: recentActivity.slice(0, 5),
        // Latest 5 activities for dashboard
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats", error: error.message });
    }
  });
  app2.get("/api/admin/users", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { search, role, limit = "50", offset = "0" } = req.query;
      let users3;
      if (search) {
        users3 = await storage.searchUsers(search, parseInt(limit));
      } else if (role) {
        users3 = await storage.getUsersByRole(role);
      } else {
        users3 = await storage.getAllUsersWithRoles();
      }
      const usersWithStats = await Promise.all(
        users3.slice(parseInt(offset), parseInt(offset) + parseInt(limit)).map(async (user) => {
          const stats = await storage.getUserStats(user.id);
          return {
            ...user,
            stats,
            // Remove sensitive data
            password: void 0
          };
        })
      );
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "users_list_accessed",
        resource: "user_management",
        resourceId: null,
        oldValue: null,
        newValue: {
          searchQuery: search || null,
          roleFilter: role || null,
          resultCount: usersWithStats.length
        },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json({
        users: usersWithStats,
        total: users3.length,
        offset: parseInt(offset),
        limit: parseInt(limit)
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users", error: error.message });
    }
  });
  app2.get("/api/admin/users/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const [user, userWithRoles, userStats] = await Promise.all([
        storage.getUser(id),
        RBACService.getUserWithPermissions(id),
        storage.getUserStats(id)
      ]);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "user_details_accessed",
        resource: "user_management",
        resourceId: id,
        oldValue: null,
        newValue: { accessedUser: id },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json({
        ...user,
        password: void 0,
        // Never expose passwords
        roles: userWithRoles?.userRoles || [],
        permissions: userWithRoles?.permissions || [],
        stats: userStats
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user details", error: error.message });
    }
  });
  app2.post("/api/admin/users", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
      let hashedPassword;
      if (userData.password) {
        hashedPassword = await bcrypt.hash(userData.password, 10);
      }
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
        authProvider: userData.authProvider || "local"
      });
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "user_created",
        resource: "users",
        resourceId: user.id,
        oldValue: null,
        newValue: { ...userData, password: userData.password ? "[REDACTED]" : null },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.status(201).json({
        ...user,
        password: void 0
        // Never expose passwords
      });
    } catch (error) {
      res.status(400).json({ message: "Failed to create user", error: error.message });
    }
  });
  app2.put("/api/admin/users/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      if (updates.password) {
        updates.password = await bcrypt.hash(updates.password, 10);
      }
      const updatedUser = await storage.updateUser(id, updates);
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "user_updated",
        resource: "users",
        resourceId: id,
        oldValue: { ...existingUser, password: "[REDACTED]" },
        newValue: { ...updates, password: updates.password ? "[REDACTED]" : void 0 },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json({
        ...updatedUser,
        password: void 0
        // Never expose passwords
      });
    } catch (error) {
      res.status(400).json({ message: "Failed to update user", error: error.message });
    }
  });
  app2.get("/api/admin/roles/matrix", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const [permissionMatrix, allPermissions, allRoles] = await Promise.all([
        storage.getPermissionMatrix(),
        storage.getPermissions(),
        storage.getRoles()
      ]);
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "permission_matrix_accessed",
        resource: "role_management",
        resourceId: null,
        oldValue: null,
        newValue: { timestamp: (/* @__PURE__ */ new Date()).toISOString() },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json({
        matrix: permissionMatrix,
        permissions: allPermissions,
        roles: allRoles,
        categories: [...new Set(allPermissions.map((p) => p.category))]
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch permission matrix", error: error.message });
    }
  });
  app2.get("/api/admin/audit-logs/enhanced", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const {
        userId,
        action,
        resource,
        startDate,
        endDate,
        limit = "100",
        offset = "0"
      } = req.query;
      const auditLogs = await storage.getAuditLogs(
        userId,
        parseInt(limit)
      );
      let filteredLogs = auditLogs;
      if (action) {
        filteredLogs = filteredLogs.filter((log2) => log2.action.includes(action));
      }
      if (resource) {
        filteredLogs = filteredLogs.filter((log2) => log2.resource.includes(resource));
      }
      if (startDate || endDate) {
        const start = startDate ? new Date(startDate) : /* @__PURE__ */ new Date(0);
        const end = endDate ? new Date(endDate) : /* @__PURE__ */ new Date();
        filteredLogs = filteredLogs.filter(
          (log2) => log2.timestamp >= start && log2.timestamp <= end
        );
      }
      const paginatedLogs = filteredLogs.slice(
        parseInt(offset),
        parseInt(offset) + parseInt(limit)
      );
      res.json({
        logs: paginatedLogs,
        total: filteredLogs.length,
        offset: parseInt(offset),
        limit: parseInt(limit),
        filters: { userId, action, resource, startDate, endDate }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch enhanced audit logs", error: error.message });
    }
  });
  app2.get("/api/admin/system/health", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const startTime = Date.now();
      const dbHealthStart = Date.now();
      const [testQuery] = await db.select({ count: sql`count(*)` }).from(users);
      const dbResponseTime = Date.now() - dbHealthStart;
      const systemStats = await storage.getSystemStats();
      const totalResponseTime = Date.now() - startTime;
      const healthData = {
        database: {
          status: "healthy",
          responseTime: dbResponseTime,
          connectionStatus: "connected"
        },
        api: {
          status: "healthy",
          responseTime: totalResponseTime
        },
        system: {
          ...systemStats,
          uptime: process.uptime(),
          memory: process.memoryUsage(),
          nodeVersion: process.version
        },
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "system_health_checked",
        resource: "system_monitoring",
        resourceId: null,
        oldValue: null,
        newValue: { responseTime: totalResponseTime },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json(healthData);
    } catch (error) {
      res.status(500).json({
        message: "System health check failed",
        error: error.message,
        database: { status: "error", responseTime: -1 },
        api: { status: "error", responseTime: -1 }
      });
    }
  });
  app2.get("/api/admin/settings", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const settings = {
        security: {
          passwordPolicy: {
            minLength: 8,
            requireUppercase: true,
            requireLowercase: true,
            requireNumbers: true,
            requireSpecialChars: false
          },
          sessionTimeout: 30,
          // minutes
          maxLoginAttempts: 5,
          lockoutDuration: 15
          // minutes
        },
        email: {
          fromAddress: process.env.EMAIL_FROM || "noreply@jeldi.com",
          smtpEnabled: !!process.env.SMTP_HOST
        },
        oauth: {
          googleEnabled: !!process.env.GOOGLE_CLIENT_ID,
          microsoftEnabled: !!process.env.MICROSOFT_CLIENT_ID
        },
        features: {
          erpIntegrations: true,
          aiAssistant: true,
          emailCenter: true,
          advancedAnalytics: true
        },
        system: {
          maintenanceMode: false,
          debugMode: process.env.NODE_ENV === "development",
          logLevel: "info"
        }
      };
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch system settings", error: error.message });
    }
  });
  app2.put("/api/admin/settings", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { category, settings } = req.body;
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "system_settings_updated",
        resource: "system_settings",
        resourceId: category,
        oldValue: null,
        // Would fetch current settings
        newValue: settings,
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.json({
        message: "Settings updated successfully",
        category,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      res.status(400).json({ message: "Failed to update settings", error: error.message });
    }
  });
  app2.get("/api/admin/activity/stream", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { limit = "20" } = req.query;
      const recentActivity = await storage.getRecentActivity(parseInt(limit));
      res.json({
        activities: recentActivity,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activity stream", error: error.message });
    }
  });
  app2.get("/api/admin/export/:type", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { type } = req.params;
      const { format = "json" } = req.query;
      let data;
      let filename;
      switch (type) {
        case "users":
          data = await storage.getAllUsersWithRoles();
          filename = `users_export_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}`;
          break;
        case "audit-logs":
          data = await storage.getAuditLogs(void 0, 1e3);
          filename = `audit_logs_export_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}`;
          break;
        case "roles":
          data = await storage.getRoles();
          filename = `roles_export_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}`;
          break;
        default:
          return res.status(400).json({ message: "Invalid export type" });
      }
      await RBACService.logAuditEvent({
        userId: req.user.id,
        action: "data_exported",
        resource: "system_data",
        resourceId: type,
        oldValue: null,
        newValue: { type, format, recordCount: Array.isArray(data) ? data.length : 1 },
        ipAddress: req.ip,
        userAgent: req.get("User-Agent") || null
      });
      res.setHeader("Content-Disposition", `attachment; filename="${filename}.${format}"`);
      res.setHeader("Content-Type", format === "json" ? "application/json" : "text/csv");
      if (format === "json") {
        res.json(data);
      } else {
        res.json({ message: "CSV export not implemented yet", data });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to export data", error: error.message });
    }
  });
  app2.get("/api/kpis", authenticateToken, requirePermission("kpis", "read"), async (req, res) => {
    try {
      const kpis = await storage.getKpiConfigurations(req.user.id);
      const kpisWithData = await Promise.all(
        kpis.map(async (kpi) => {
          const latestData = await storage.getLatestKpiData(kpi.id);
          return { ...kpi, latestData };
        })
      );
      res.json(kpisWithData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch KPIs", error: error.message });
    }
  });
  app2.post("/api/kpis", authenticateToken, requirePermission("kpis", "create"), async (req, res) => {
    try {
      const kpiData2 = insertKpiConfigurationSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      const kpi = await storage.createKpiConfiguration(kpiData2);
      res.json(kpi);
    } catch (error) {
      res.status(400).json({ message: "Failed to create KPI", error: error.message });
    }
  });
  app2.put("/api/kpis/:id", authenticateToken, requirePermission("kpis", "update"), async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const kpi = await storage.updateKpiConfiguration(id, updates);
      if (!kpi) {
        return res.status(404).json({ message: "KPI not found" });
      }
      res.json(kpi);
    } catch (error) {
      res.status(400).json({ message: "Failed to update KPI", error: error.message });
    }
  });
  app2.delete("/api/kpis/:id", authenticateToken, requirePermission("kpis", "delete"), async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteKpiConfiguration(id);
      if (!success) {
        return res.status(404).json({ message: "KPI not found" });
      }
      res.json({ message: "KPI deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete KPI", error: error.message });
    }
  });
  app2.get("/api/email/providers", authenticateToken, requirePermission("email", "manage"), async (req, res) => {
    try {
      const configurations = await emailService.getEmailConfigurations(req.user.id);
      const outlookStatus = await emailService.checkOutlookConnection();
      res.json({
        configurations,
        templates: emailService.getEmailTemplates(),
        connectionStatus: {
          outlook: outlookStatus
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch email providers", error: error.message });
    }
  });
  app2.get("/api/email/status", authenticateToken, requirePermission("email", "manage"), async (req, res) => {
    try {
      const outlookStatus = await emailService.checkOutlookConnection();
      const configurations = await emailService.getEmailConfigurations(req.user.id);
      const gmailConfig = configurations.find((c) => c.provider === "gmail" && c.isActive);
      res.json({
        outlook: outlookStatus,
        gmail: {
          isConnected: !!gmailConfig,
          email: gmailConfig?.email
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to check email status", error: error.message });
    }
  });
  app2.post("/api/email/connect/:provider", authenticateToken, requirePermission("email", "manage"), async (req, res) => {
    try {
      const { provider } = emailProviderParamsSchema.parse(req.params);
      const recentConfigs = await emailService.getEmailConfigurations(req.user.id);
      const recentAttempts = recentConfigs.filter(
        (c) => c.provider === provider && c.createdAt && (/* @__PURE__ */ new Date()).getTime() - new Date(c.createdAt).getTime() < 5 * 60 * 1e3
        // 5 minutes
      );
      if (recentAttempts.length > 3) {
        return res.status(429).json({
          message: "Too many connection attempts. Please wait before trying again.",
          retryAfter: 300
          // 5 minutes
        });
      }
      if (provider === "outlook") {
        const outlookStatus = await emailService.checkOutlookConnection();
        if (outlookStatus.isConnected) {
          res.json({
            message: "Outlook is already connected via Replit connector",
            isConnected: true,
            email: outlookStatus.email
          });
        } else {
          res.status(400).json({
            message: "Outlook connector not configured. Please set up the Outlook integration in your Replit project.",
            requiresSetup: true
          });
        }
      } else if (provider === "gmail") {
        const redirectUri = process.env.EMAIL_OAUTH_REDIRECT_URI || `${req.protocol}://${req.get("host")}/api/email/callback`;
        const authUrl = await emailService.initiateEmailOAuth(provider, req.user.id, redirectUri);
        console.log(`OAuth initiated for user ${req.user.id} with provider ${provider} at ${(/* @__PURE__ */ new Date()).toISOString()}`);
        res.json({ authUrl });
      } else if (provider === "smtp") {
        const smtpConfig = smtpConfigRequestSchema.parse(req.body);
        const encryptedPassword = await emailService.encryptToken(smtpConfig.password);
        const emailConfig = {
          userId: req.user.id,
          provider: "smtp",
          email: smtpConfig.username,
          accessToken: JSON.stringify({
            host: smtpConfig.host,
            port: smtpConfig.port,
            secure: smtpConfig.secure,
            // Properly parsed boolean from Zod
            auth: {
              user: smtpConfig.username,
              pass: encryptedPassword
            }
          }),
          isActive: true
        };
        await storage.createEmailConfiguration(emailConfig);
        res.json({
          message: "SMTP configuration saved successfully",
          isConnected: true
        });
      }
    } catch (error) {
      console.error("Email provider connection error:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({
          message: "Invalid input data",
          errors: error.errors,
          type: "validation_error"
        });
      }
      if (error instanceof Error && error.message.includes("Failed to encrypt")) {
        return res.status(500).json({
          message: "Security configuration error. Please contact support.",
          type: "encryption_error"
        });
      }
      res.status(400).json({
        message: "Failed to connect email provider",
        error: error.message,
        type: "connection_error"
      });
    }
  });
  app2.get("/api/email/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      if (!code || !state) {
        return res.status(400).json({ message: "Missing code or state parameter" });
      }
      const config = await emailService.handleEmailOAuthCallback(code, state);
      res.redirect(`${process.env.FRONTEND_URL || "http://localhost:5000"}/dashboard?email_connected=${config.provider}`);
    } catch (error) {
      res.status(400).json({ message: "Email OAuth callback failed", error: error.message });
    }
  });
  app2.post("/api/email/send", authenticateToken, requirePermission("email", "send"), async (req, res) => {
    try {
      const emailRequest = emailSendRequestSchema.parse(req.body);
      const rateLimitKey = `email_send_${req.user.id}`;
      const now = Date.now();
      const rateLimit = global[rateLimitKey] || [];
      const recentSends = rateLimit.filter((timestamp2) => now - timestamp2 < 6e4);
      if (recentSends.length >= 10) {
        return res.status(429).json({
          message: "Rate limit exceeded. Maximum 10 emails per minute.",
          retryAfter: 60,
          limit: 10,
          windowMs: 6e4
        });
      }
      recentSends.push(now);
      global[rateLimitKey] = recentSends;
      const emailMessage = {
        to: emailRequest.to,
        cc: emailRequest.cc,
        bcc: emailRequest.bcc,
        subject: emailRequest.subject || "",
        body: emailRequest.body || "",
        isHtml: emailRequest.isHtml
      };
      const success = await emailService.sendEmail(
        req.user.id,
        emailRequest.provider,
        emailMessage,
        emailRequest.template,
        emailRequest.templateVariables
      );
      if (success) {
        res.json({ message: "Email sent successfully" });
      } else {
        res.status(500).json({ message: "Failed to send email" });
      }
    } catch (error) {
      console.error("Email send error:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({
          message: "Invalid email data",
          errors: error.errors,
          type: "validation_error"
        });
      }
      if (error instanceof Error && error.message.includes("authentication failed")) {
        return res.status(401).json({
          message: "Email provider authentication failed. Please reconnect your email account.",
          type: "auth_error"
        });
      }
      if (error instanceof Error && error.message.includes("Rate limit")) {
        return res.status(429).json({
          message: "Too many email requests. Please try again later.",
          type: "rate_limit_error"
        });
      }
      res.status(500).json({
        message: "Failed to send email",
        error: error.message,
        type: "send_error"
      });
    }
  });
  app2.get("/api/email/templates", authenticateToken, requirePermission("email", "send"), async (req, res) => {
    try {
      const templates = emailService.getEmailTemplates();
      res.json({
        templates,
        count: Object.keys(templates).length,
        available: Object.keys(templates)
      });
    } catch (error) {
      res.status(500).json({
        message: "Failed to fetch email templates",
        error: error.message
      });
    }
  });
  app2.post("/api/chat/query", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const { query } = req.body;
      let defaultConversation;
      const conversations2 = await storage.getConversations(req.user.id, 1);
      if (conversations2.length === 0) {
        defaultConversation = await storage.createConversation({
          userId: req.user.id,
          title: "Default Chat",
          description: "Legacy chat conversation",
          isFavorite: false
        });
      } else {
        defaultConversation = conversations2[0];
      }
      const erpData = await erpService.aggregateERPData(req.user.id);
      let response;
      try {
        response = await analyzeERPData({
          query,
          erpData,
          userId: req.user.id
        });
      } catch (aiError) {
        console.error("AI analysis failed:", aiError);
        response = {
          response: "AI analysis temporarily unavailable: " + aiError.message,
          insights: [],
          recommendations: [],
          dataUsed: []
        };
      }
      await storage.createChatHistory({
        conversationId: defaultConversation.id,
        userId: req.user.id,
        query,
        response: response.response,
        erpData,
        insights: response.insights || [],
        recommendations: response.recommendations || [],
        dataUsed: response.dataUsed || []
      });
      const wsClient = wsClients.get(req.user.id);
      if (wsClient && wsClient.ws.readyState === WebSocket.OPEN && wsClient.permissions.includes("ai.basic")) {
        wsClient.ws.send(JSON.stringify({
          type: "chat_response",
          data: response
        }));
      }
      res.json(response);
    } catch (error) {
      res.status(500).json({ message: "Failed to process query", error: error.message });
    }
  });
  app2.get("/api/chat/history", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const history = await storage.getChatHistory(req.user.id);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat history", error: error.message });
    }
  });
  app2.get("/api/conversations", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 50;
      const conversations2 = await storage.getConversations(req.user.id, limit);
      res.json(conversations2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversations", error: error.message });
    }
  });
  app2.get("/api/conversations/:id", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const conversation = await storage.getConversation(req.params.id);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      if (conversation.userId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      const messages = await storage.getChatHistoryByConversation(conversation.id);
      res.json({ ...conversation, messages });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversation", error: error.message });
    }
  });
  app2.post("/api/conversations", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const { title, description } = req.body;
      if (!title) {
        return res.status(400).json({ message: "Conversation title is required" });
      }
      const conversation = await storage.createConversation({
        userId: req.user.id,
        title: title.slice(0, 100),
        // Limit title length
        description: description?.slice(0, 500)
        // Limit description length
      });
      res.json(conversation);
    } catch (error) {
      res.status(500).json({ message: "Failed to create conversation", error: error.message });
    }
  });
  app2.put("/api/conversations/:id", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const conversation = await storage.getConversation(req.params.id);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      if (conversation.userId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      const { title, description, isFavorite } = req.body;
      const updates = {};
      if (title !== void 0) updates.title = title.slice(0, 100);
      if (description !== void 0) updates.description = description?.slice(0, 500);
      if (isFavorite !== void 0) updates.isFavorite = Boolean(isFavorite);
      const updatedConversation = await storage.updateConversation(req.params.id, updates);
      res.json(updatedConversation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update conversation", error: error.message });
    }
  });
  app2.delete("/api/conversations/:id", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const conversation = await storage.getConversation(req.params.id);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      if (conversation.userId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      const deleted = await storage.deleteConversation(req.params.id);
      if (deleted) {
        res.json({ message: "Conversation deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete conversation" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete conversation", error: error.message });
    }
  });
  app2.post("/api/chat/conversations/:id/message", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const { query } = req.body;
      const conversationId = req.params.id;
      const conversation = await storage.getConversation(conversationId);
      if (!conversation || conversation.userId !== req.user.id) {
        return res.status(404).json({ message: "Conversation not found or access denied" });
      }
      const previousMessages = await storage.getChatHistoryByConversation(conversationId, 10);
      const erpData = await erpService.aggregateERPData(req.user.id);
      const startTime = Date.now();
      let response;
      try {
        response = await analyzeERPData({
          query,
          erpData,
          userId: req.user.id
        });
      } catch (aiError) {
        console.error("AI analysis failed:", aiError);
        response = {
          response: "AI analysis temporarily unavailable: " + aiError.message,
          insights: [],
          recommendations: [],
          dataUsed: []
        };
      }
      const responseTime = Date.now() - startTime;
      await storage.createChatHistory({
        conversationId,
        userId: req.user.id,
        query,
        response: response.response,
        insights: response.insights,
        recommendations: response.recommendations,
        dataUsed: response.dataUsed,
        erpData,
        responseTime
      });
      await storage.updateConversation(conversationId, {
        lastMessageAt: /* @__PURE__ */ new Date(),
        messageCount: conversation.messageCount + 1
      });
      const wsClient = wsClients.get(req.user.id);
      if (wsClient && wsClient.ws.readyState === WebSocket.OPEN && wsClient.permissions.includes("ai.basic")) {
        wsClient.ws.send(JSON.stringify({
          type: "chat_response",
          conversationId,
          data: response
        }));
      }
      res.json(response);
    } catch (error) {
      res.status(500).json({ message: "Failed to process message", error: error.message });
    }
  });
  app2.get("/api/query-templates", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const category = req.query.category;
      const systemTemplates = await storage.getQueryTemplates(category);
      const userTemplates = await storage.getUserQueryTemplates(req.user.id);
      res.json({
        system: systemTemplates,
        user: userTemplates
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch query templates", error: error.message });
    }
  });
  app2.post("/api/query-templates", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const { name, description, query, category, icon } = req.body;
      if (!name || !query || !category) {
        return res.status(400).json({ message: "Name, query, and category are required" });
      }
      const template = await storage.createQueryTemplate({
        name: name.slice(0, 100),
        description: description?.slice(0, 500),
        query: query.slice(0, 2e3),
        category: category.slice(0, 50),
        icon: icon || "fas fa-question-circle",
        isSystem: false,
        userId: req.user.id
      });
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to create query template", error: error.message });
    }
  });
  app2.post("/api/query-templates/:id/use", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      await storage.updateQueryTemplateUsage(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to update template usage", error: error.message });
    }
  });
  app2.get("/api/favorite-queries", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const category = req.query.category;
      const favorites = await storage.getFavoriteQueries(req.user.id, category);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorite queries", error: error.message });
    }
  });
  app2.post("/api/favorite-queries", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const { query, title, description, category } = req.body;
      if (!query || !title || !category) {
        return res.status(400).json({ message: "Query, title, and category are required" });
      }
      const favorite = await storage.createFavoriteQuery({
        userId: req.user.id,
        query: query.slice(0, 2e3),
        title: title.slice(0, 100),
        description: description?.slice(0, 500),
        category: category.slice(0, 50)
      });
      res.json(favorite);
    } catch (error) {
      res.status(500).json({ message: "Failed to save favorite query", error: error.message });
    }
  });
  app2.delete("/api/favorite-queries/:id", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      const deleted = await storage.deleteFavoriteQuery(req.params.id);
      if (deleted) {
        res.json({ message: "Favorite query deleted successfully" });
      } else {
        res.status(404).json({ message: "Favorite query not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete favorite query", error: error.message });
    }
  });
  app2.post("/api/favorite-queries/:id/use", authenticateToken, requirePermission("ai", "basic"), async (req, res) => {
    try {
      await storage.updateFavoriteQueryUsage(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to update favorite usage", error: error.message });
    }
  });
  app2.get("/api/insights", authenticateToken, requirePermission("kpis", "read"), async (req, res) => {
    try {
      const kpis = await storage.getKpiConfigurations(req.user.id);
      const kpiData2 = {};
      for (const kpi of kpis) {
        const latestData = await storage.getLatestKpiData(kpi.id);
        if (latestData) {
          kpiData2[kpi.name] = {
            value: latestData.value,
            change: latestData.change,
            type: kpi.type
          };
        }
      }
      const insights = await generateKPIInsights(kpiData2);
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate insights", error: error.message });
    }
  });
  app2.get("/api/realtime/kpi-updates", authenticateToken, requirePermission("kpis", "read"), async (req, res) => {
    try {
      const kpis = await storage.getKpiConfigurations(req.user.id);
      const kpiUpdates = [];
      for (const kpi of kpis.slice(0, 5)) {
        const latestData = await storage.getLatestKpiData(kpi.id);
        if (latestData) {
          kpiUpdates.push({
            id: kpi.id,
            name: kpi.name,
            type: kpi.type,
            value: latestData.value,
            change: latestData.change,
            timestamp: latestData.timestamp
          });
        }
      }
      res.json({
        type: "kpi_update",
        data: kpiUpdates,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      res.status(500).json({
        message: "Failed to fetch KPI updates",
        error: error.message
      });
    }
  });
  app2.get("/api/realtime/erp-status", authenticateToken, requirePermission("erp_connections", "read"), async (req, res) => {
    try {
      const systems = await erpService.getConnectedSystems(req.user.id);
      const erpSystems = systems.map((system) => ({
        name: system.name,
        displayName: system.displayName,
        description: system.description,
        isConnected: system.isConnected,
        lastSync: system.lastSync,
        status: system.isConnected ? "active" : "inactive"
      }));
      res.json({
        type: "erp_status_update",
        data: erpSystems,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      res.status(500).json({
        message: "Failed to fetch ERP status",
        error: error.message
      });
    }
  });
  app2.get("/api/realtime/insights", authenticateToken, requirePermission("kpis", "read"), async (req, res) => {
    try {
      const kpis = await storage.getKpiConfigurations(req.user.id);
      const kpiData2 = {};
      for (const kpi of kpis) {
        const latestData = await storage.getLatestKpiData(kpi.id);
        if (latestData) {
          kpiData2[kpi.name] = {
            value: latestData.value,
            change: latestData.change,
            type: kpi.type
          };
        }
      }
      const insights = await generateKPIInsights(kpiData2);
      res.json({
        type: "insights_update",
        data: {
          summary: insights.summary || "",
          alerts: insights.alerts || [],
          trends: insights.trends || []
        },
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      res.status(500).json({
        message: "Failed to generate insights",
        error: error.message
      });
    }
  });
  const httpServer = createServer(app2);
  if (!options.excludeWebSocket) {
    const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
    wss.on("connection", (ws2, req) => {
      console.log("WebSocket client connected");
      ws2.on("message", async (data) => {
        try {
          const message = JSON.parse(data.toString());
          if (message.type === "auth" && message.token) {
            try {
              const decoded = jwt2.verify(message.token, getJwtSecret());
              const user = await storage.getUser(decoded.userId);
              if (user) {
                const userWithPermissions = await RBACService.getUserWithPermissions(user.id);
                if (userWithPermissions) {
                  wsClients.set(user.id, {
                    ws: ws2,
                    user,
                    permissions: userWithPermissions.permissions.map((p) => `${p.resource}.${p.action}`)
                  });
                  ws2.send(JSON.stringify({ type: "auth_success", userId: user.id }));
                } else {
                  ws2.send(JSON.stringify({ type: "auth_error", message: "Unable to load user permissions" }));
                }
              }
            } catch (error) {
              ws2.send(JSON.stringify({ type: "auth_error", message: "Invalid token" }));
            }
          }
        } catch (error) {
          console.error("WebSocket message error:", error);
        }
      });
      ws2.on("close", () => {
        for (const [userId, client] of Array.from(wsClients.entries())) {
          if (client.ws === ws2) {
            wsClients.delete(userId);
            break;
          }
        }
      });
    });
    setInterval(async () => {
      for (const [userId, client] of Array.from(wsClients.entries())) {
        if (client.ws.readyState === WebSocket.OPEN) {
          if (!client.permissions.includes("kpis.read")) {
            continue;
          }
          try {
            const kpis = await storage.getKpiConfigurations(userId);
            const kpiUpdates = [];
            for (const kpi of kpis.slice(0, 5)) {
              const latestData = await storage.getLatestKpiData(kpi.id);
              if (latestData) {
                kpiUpdates.push({
                  id: kpi.id,
                  name: kpi.name,
                  type: kpi.type,
                  value: latestData.value,
                  change: latestData.change,
                  timestamp: latestData.timestamp
                });
              }
            }
            if (kpiUpdates.length > 0) {
              client.ws.send(JSON.stringify({
                type: "kpi_update",
                data: kpiUpdates
              }));
            }
          } catch (error) {
            console.error("Error sending KPI updates:", error);
          }
        }
      }
    }, 3e4);
  }
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
enforceEnvironmentValidation();
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const allowedOrigins = [
    "https://d2k9wjgsy12ugk.cloudfront.net",
    // Original CloudFront domain
    "https://demo.jeldi.app",
    // Custom domain for main app
    "https://overlay.jeldi.app"
    // Custom domain for AI overlay
  ];
  const origin = req.headers.origin;
  res.setHeader("Vary", "Origin");
  if (origin && allowedOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  }
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization,Accept,Origin,X-Requested-With");
  res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,POST,PUT,DELETE,OPTIONS,PATCH");
  res.setHeader("Access-Control-Allow-Credentials", "false");
  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }
  next();
});
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
